package Central;

import AccountService.Card;
import AccountService.Guest;
import Room.Reservation;

import java.sql.ResultSet;
import java.util.Date;

public class CentralCashiering {
    public static boolean run() {
        /*
        ResultSet rooms = CentralDatabase.getReservations();
        try {
            while(rooms.next()) {
                String username = rooms.getString("Username");
                String password = rooms.getString("Password");
                ResultSet resSet = CentralDatabase.getGuest(username, password);
                if(resSet.next()) {
                }
            }
            return true;
        } catch (Exception e) {}

        return false;*/
        return true;
    }
    public static boolean chargeGuest(Reservation reservation) {

        return false;
    }
}
