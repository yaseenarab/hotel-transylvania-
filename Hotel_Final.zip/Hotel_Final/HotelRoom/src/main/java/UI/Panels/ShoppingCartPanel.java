package UI.Panels;

import AccountService.Guest;

import javax.swing.*;

// Panel to look at contents of cart and / or go to checkout
public class ShoppingCartPanel extends JPanel {
    private JPanel content;

    public ShoppingCartPanel(ShoppingMainPanel SMP, Guest g) {

    }
}
