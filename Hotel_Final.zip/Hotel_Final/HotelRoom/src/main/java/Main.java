
import Central.CentralDatabase;
import Central.CentralRoom;
import UI.Frames.LoginFrame;

public class Main {
    public static void main(String[] args) {
        if(!CentralRoom.initializeRooms()) {
            System.exit(1);
        }
        if(!CentralDatabase.init()) {
            System.exit(1);
        }
        LoginFrame login = new LoginFrame();
        login.setVisible(true);
    }
}
