package Hotel.UI;

import Hotel.ShoppingHandlers.ShoppingMainPanelHandler;
import Hotel.ShoppingService.ItemSpec;
import Hotel.Utilities.Utilities;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Logger;

// When shopping section is first entered
// Avenue to cart, items and checkout, or back to home
public class ShoppingMainPanel extends JPanel {
    private static final Logger SMP_Logger
            = Logger.getLogger(ShoppingMainPanel.class.getName());

    private static int itemsPerRow = 5;

    private static JPanel header;

    // interactive content below header
    private static JPanel content;

    // ShoppingCartPanel
    private static JPanel SCP;

    // ShoppingItemPanel
    private static JPanel SIP;

    // ShoppingCheckoutPanel
    private static JPanel SCOP;

    private static JPanel ItemContainers;

    private static JPanel searchPanel;

    private static JLabel hotelLogoLabel;

    private static JButton homeBtn;

    private static JButton cartBtn;

    private static JButton searchBtn;

    private static JTextField searchBar;

    public static CardLayout cl;

    public ShoppingMainPanel(GuestHomeFrame frame) {
        // Container initialization
        frame.container = new JPanel();

        // Header initialization
        header = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 20));

        // Subcontent initialization
        cl = new CardLayout();
        content = new JPanel(cl);
/*
        // Header - Logo
        try {
           // BufferedImage hotelLogo = Utilities.generateImage(this, "Hotel_Transylvania_logo.png");
                    /*
                    ImageIO.read(
                            new File(
                                    Objects.requireNonNull(
                                            this.getClass()
                                                    .getResource("/Hotel_Transylvania_logo.png")).getFile()));

            //hotelLogoLabel = new JLabel(new ImageIcon(hotelLogo));
        } catch (IOException e) {
            SMP_Logger.warning("Unable to load hotel logo");
            hotelLogoLabel = new JLabel(new ImageIcon());
        }
        hotelLogoLabel.setMinimumSize(new Dimension(80, 80));
        header.add(hotelLogoLabel);

        */
        // Header - Home button
        homeBtn = new JButton("Home");
        homeBtn.addActionListener(e -> frame.cl.show(frame.container, "Home"));
        header.add(homeBtn);

        // Header - Search panel (search bar & button)
        searchBar = new JTextField();
        searchBar.setMinimumSize(new Dimension(100, 30));
        //header.add(search);
        searchPanel = new JPanel(new FlowLayout());
        searchPanel.add(searchBar);
        /*
        try {
            BufferedImage searchIcon = Utilities.generateImage(this, "Hotel_Transylvania_logo.png");
                    /*
                    ImageIO.read(
                            new File(
                                    Objects.requireNonNull(
                                            this.getClass()
                                                    .getResource("/Hotel_Transylvania_logo.png")).getFile()));

            searchBtn = new JButton(new ImageIcon(searchIcon));
        } catch (IOException e) {
            SMP_Logger.warning("Unable to load search icon");
            searchBtn = new JButton(new ImageIcon());
        }
        searchBtn.setMinimumSize(new Dimension(50, 50));
        searchPanel.add(searchBtn);

         */

        // Header - Cart button
        cartBtn = new JButton("Cart ("
                + ShoppingMainPanelHandler.getNumberItemsInCart(frame.getGuest().getCart())
                + ")"
        );
        cartBtn.addActionListener(e -> {
            SCP = new ShoppingCartPanel(this, frame.getGuest());
            content.add(SCP, "Cart");
            cl.show(content, "Cart");
        });
        header.add(cartBtn);

        // Container - Adding header
        header.setMinimumSize(new Dimension(720, 80));
        frame.container.add(header, BorderLayout.NORTH);

        // Content initialization
        ArrayList<ItemSpec> isl = ShoppingMainPanelHandler.loadItems();
        ArrayList<JPanel> itemPanels = new ArrayList<>();
        for (var is : isl) {
            JPanel itemPanel = new JPanel();
            itemPanel.setLayout(new BoxLayout(itemPanel, BoxLayout.Y_AXIS));

            JLabel itemTitle = new JLabel(is.getName());

            JLabel itemPic;
            try {
                BufferedImage itemBU = Utilities.generateImage(this, is.getImageURL());
                itemPic = new JLabel(new ImageIcon(itemBU));
            } catch (IOException e) {
                SMP_Logger.severe("Could not generate image of item : " + is.getName());
                itemPic = new JLabel(new ImageIcon());
            }
            itemPic.setMinimumSize(new Dimension(180, 100));

            JLabel itemPrice = new JLabel(is.getPrice().toString());

            itemPanel.add(itemTitle);
            itemPanel.add(itemPic);
            itemPanel.add(itemPrice);
            itemPanel.setSize(new Dimension(200, 200));

            itemPanels.add(itemPanel);
        }

        ItemContainers = new JPanel(new GridBagLayout());
        GridBagConstraints gbc =  new GridBagConstraints();
        for (JPanel itemPanel : itemPanels) {
            ItemContainers.add(itemPanel);
            gbc.gridx = (gbc.gridx + 1) % itemsPerRow;
            if (gbc.gridx == 0) { ++gbc.gridy; }
        }
        JScrollBar scrollbar = new JScrollBar();
        ItemContainers.add(scrollbar);
    }

    public static void main(String[] args) {

    }
}