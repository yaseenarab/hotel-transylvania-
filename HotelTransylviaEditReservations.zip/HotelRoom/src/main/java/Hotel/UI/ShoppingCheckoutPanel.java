package Hotel.UI;

import javax.swing.*;

// Panel for finalizing items in cart to add to final bill
public class ShoppingCheckoutPanel extends JPanel {
    private JPanel content;
}