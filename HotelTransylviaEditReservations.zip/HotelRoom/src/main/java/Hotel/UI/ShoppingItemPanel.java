package Hotel.UI;

import javax.swing.*;

import Hotel.ShoppingService.ItemSpec;

// Panel for individual items
public class ShoppingItemPanel extends JPanel {
    private JPanel content;

    private ItemSpec item;

    public ShoppingItemPanel(ShoppingMainPanel SMP, ItemSpec is) {
        item = is;
    }
}