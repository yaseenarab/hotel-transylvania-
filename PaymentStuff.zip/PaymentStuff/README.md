# Hotel Transylvania

Welcome to the Hotel Transylvania stay-and-shop reservation system! We are currently developing a monolithic application designed to offer a shopping experience and managing reservations for guests. Additionally, the system allows for hotel-wide reservation and room management for clerks, as well as additional functionalities for administrators.

Our main branch currently contains functionality implemented during Iteration 2.

Further information about our project and our team members can be found on the Wiki tab or [through this link!](<https://github.com/yaseenarab/hotel-transylvania-/wiki>)
