package Hotel.AccountService;

import Hotel.Room.Reservation;
import Hotel.Central.CentralRoom;
import Hotel.Central.CentralReservations;

import java.util.List;
import java.math.BigDecimal;
import java.util.Map;

public class PaymentInfo {
    private String cardNumber;
    private String cardHolder;
    private String expiryDate;
    private String cvv;
    private BigDecimal totalCost;
    private Guest guest;

    public PaymentInfo(String cardNumber, String cardHolder, String expiryDate, String cvv, Guest guest) {
        this.cardNumber = cardNumber;
        this.cardHolder = cardHolder;
        this.expiryDate = expiryDate;
        this.cvv = cvv;
        this.guest = guest;
        this.totalCost = calculateTotalCost(guest);
    }

    public BigDecimal calculateTotalCost(Guest guest) {
        BigDecimal total = BigDecimal.ZERO;
        Map<String, Reservation> reservations = CentralReservations.getReservations(guest);
        for (Reservation reservation : reservations.values()) {
            BigDecimal roomCost = CentralRoom.calculatorCost(reservation.getRoomID());
            long diff = reservation.getEndDate().getTime() - reservation.getStartDate().getTime();
            long days = diff / (24 * 60 * 60 * 1000);
            days = days > 0 ? days : 1; // Ensure at least one day is charged
            BigDecimal totalCostForReservation = roomCost.multiply(BigDecimal.valueOf(days));
            total = total.add(totalCostForReservation);
        }
        return total;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getCardHolder() {
        return cardHolder;
    }

    public void setCardHolder(String cardHolder) {
        this.cardHolder = cardHolder;
    }

    public String getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
    }

    public String getCvv() {
        return cvv;
    }

    public void setCvv(String cvv) {
        this.cvv = cvv;
    }


}