package Hotel.AccountService;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class PaymentService {

    public boolean processPayment(PaymentInfo paymentInfo) {
        if (isValid(paymentInfo)) {
            System.out.println("Payment processed successfully for: " + paymentInfo.getCardHolder());
            return true;
        } else {
            System.out.println("Payment failed for: " + paymentInfo.getCardHolder());
            return false;
        }
    }

    private boolean isValid(PaymentInfo paymentInfo) {
        return paymentInfo.getCardNumber().matches("\\d{16}") &&
                paymentInfo.getCvv().matches("\\d{3}") &&
                validExpiryDate(paymentInfo.getExpiryDate());
    }

    private boolean validExpiryDate(String expiryDate) {
        SimpleDateFormat sdf = new SimpleDateFormat("MM/yy");
        sdf.setLenient(false);
        try {
            Date expDate = sdf.parse(expiryDate);
            Calendar cal = Calendar.getInstance();
            cal.setTime(expDate);
            cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
            return cal.getTime().after(new Date());
        } catch (ParseException e) {
            return false;
        }
    }
}