package Hotel.UI;

import Hotel.AccountService.Guest;
import Hotel.Central.CentralProfiles;
import Hotel.UI.EditReservationFrame;
import Hotel.UI.LoginFrame;
//import UI.Frames.PaymentFrame;
import Hotel.UI.ReserveRoomPanel;
import Hotel.UI.ShoppingMainPanel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GuestHomeFrame extends JFrame {
    private Guest guest;
    public CardLayout cl;
    public JPanel container;
    private JPanel homePanel;
    private JPanel reservePanel;
    private JPanel editPanel;
    private JPanel shoppingPanel;
    private JLabel welcomeLabel;
    private GridBagConstraints gbc;
    private JButton editReservationBtn;
    private JButton reserveRoomBtn;
    private JButton shoppingBtn;
    private JButton logoutBtn;
    private JButton makePaymentBtn;

    public Guest getGuest() { return guest; }

    public GuestHomeFrame(String username, String password) throws IllegalArgumentException {
        if(username == null || username.isEmpty()) {
            throw new IllegalArgumentException("ERR: Invalid Guest username");
        }

        this.guest = CentralProfiles.getGuest(username, password);
        initializeComponents();
    }

    private void initializeComponents() {
        setTitle("Hotel Transylvania");
        setSize(new Dimension(720, 480));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Center the frame on the screen

        cl = new CardLayout();
        container = new JPanel(cl);
        homePanel = new JPanel(new GridBagLayout());
        welcomeLabel = new JLabel("Welcome, " + guest.getUsername());
        welcomeLabel.setFont(new Font("Helvetica", Font.PLAIN, 40));
        welcomeLabel.setHorizontalAlignment(SwingConstants.CENTER);

        editReservationBtn = new JButton("Edit Reservations");
        editReservationBtn.addActionListener(e -> {
            JFrame editPanel = new EditReservationFrame(guest);
            editPanel.setVisible(true);
        });

        reserveRoomBtn = new JButton("Reserve Room");
        reserveRoomBtn.addActionListener(e -> {
            try {
                reservePanel = new ReserveRoomPanel(GuestHomeFrame.this, guest);
            } catch (Exception ex) {
                throw new RuntimeException(ex);
            }
            container.add(reservePanel, "Reserve");
            cl.show(container, "Reserve");
        });

        shoppingBtn = new JButton("Shop");
        shoppingBtn.addActionListener(e -> {
            shoppingPanel = new ShoppingMainPanel(GuestHomeFrame.this);
            container.add(shoppingPanel, "Shop");
            cl.show(container, "Shop");
        });

        logoutBtn = new JButton("Logout");
        logoutBtn.addActionListener(e -> {
            new LoginFrame();
            dispose();
        });

        makePaymentBtn = new JButton("Make Payment");
        makePaymentBtn.addActionListener(e -> {
            PaymentFrame paymentFrame = new PaymentFrame(guest);
            paymentFrame.setVisible(true);
        });

        gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.gridx = gbc.gridy = 0;
        homePanel.add(welcomeLabel, gbc);

        JPanel buttons = new JPanel(new FlowLayout());
        buttons.add(editReservationBtn);
        buttons.add(reserveRoomBtn);
        buttons.add(shoppingBtn);
        buttons.add(logoutBtn);
        buttons.add(makePaymentBtn); // Adding the Make Payment button here

        gbc.gridy = 1;
        homePanel.add(buttons, gbc);

        container.add(homePanel, "Home");
        add(container);
        setVisible(true);
    }
}