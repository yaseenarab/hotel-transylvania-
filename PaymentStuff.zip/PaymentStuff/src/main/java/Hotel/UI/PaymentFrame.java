package Hotel.UI;

import Hotel.AccountService.Guest;
import Hotel.AccountService.PaymentInfo;
import Hotel.AccountService.PaymentService;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.math.BigDecimal;

public class PaymentFrame extends JFrame {
    private JTextField cardNumberField, cardHolderField, expiryDateField, cvvField;
    private JButton submitButton;
    private JLabel totalCostLabel, statusLabel;
    private Guest guest;

    public PaymentFrame(Guest guest) {
        this.guest = guest;
        setTitle("Payment");
        setSize(350, 300);
        setLayout(new GridLayout(8, 2));

        add(new JLabel("Card Number:"));
        cardNumberField = new JTextField(16);
        add(cardNumberField);

        add(new JLabel("Card Holder:"));
        cardHolderField = new JTextField(50);
        add(cardHolderField);

        add(new JLabel("Expiry Date (MM/YY):"));
        expiryDateField = new JTextField(5);
        add(expiryDateField);

        add(new JLabel("CVV:"));
        cvvField = new JTextField(3);
        add(cvvField);

        add(new JLabel("Total Cost of Reservation(s):"));
        totalCostLabel = new JLabel();
        add(totalCostLabel);

        submitButton = new JButton("Submit Payment");
        submitButton.addActionListener(this::processPayment);
        add(submitButton);

        statusLabel = new JLabel();
        add(statusLabel);

        setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);

        updateTotalCost();
    }

    private void updateTotalCost() {
        // Assume calculateTotalCost returns BigDecimal
        BigDecimal totalCost = new PaymentInfo("", "", "", "", guest).calculateTotalCost(guest);
        totalCostLabel.setText("Total: $" + totalCost.toString());
    }

    private void processPayment(ActionEvent e) {
        PaymentInfo paymentInfo = new PaymentInfo(
                cardNumberField.getText(),
                cardHolderField.getText(),
                expiryDateField.getText(),
                cvvField.getText(),
                guest
        );
        PaymentService service = new PaymentService();
        boolean result = service.processPayment(paymentInfo);
        if (result) {
            statusLabel.setText("Payment Successful!");
        } else {
            statusLabel.setText("Payment Failed");
        }
    }
}