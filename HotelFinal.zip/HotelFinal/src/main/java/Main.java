
import Hotel.Central.CentralDatabase;
import Hotel.LoggerPackage.MyLogger;
import Hotel.UI.LoginFrame;

import java.util.logging.Level;

public class Main {
    public static void main(String[] args) {
        if(!CentralDatabase.init()) {
            MyLogger.logger.log(Level.SEVERE, "Cannot initialize Central Database. Exiting program...");
            System.exit(1);
        }
        
        LoginFrame login = new LoginFrame();
        login.setVisible(true);
    }


}
