package Central;

import Databases.*;
import LoggerPackage.MyLogger;
import Room.Marsha;
import Room.RentableRoom;
import Room.Reservation;
import Room.RoomInitializer;

import java.lang.reflect.Method;
import java.util.Date;
import java.util.logging.Level;

public class CentralReservations {
    protected static final ReservationDatabase RESERVATION_DATABASE = new ReservationDatabase();
    private static final Marsha MARSHA = new Marsha();

    public static Reservation getReservation(String reservationID) {
        try {
            Method getReservation = ReservationDatabase.class.getDeclaredMethod("getReservation", String.class);
            getReservation.setAccessible(true);
            return ((Reservation) (getReservation.invoke(RESERVATION_DATABASE,reservationID)));
        }
        catch (Exception e) {
            MyLogger.logger.log(Level.SEVERE, "Error caught in CentralReservations.getReservation: " +
                    "Cannot invoke getReservation with " + reservationID);
            return null;
        }
    }
    public static String makeReservation(String roomID, String guestID, Date startDate, Date endDate) {
        if(!GuestDatabase.isIDStored(guestID)) {
            MyLogger.logger.log(Level.SEVERE, "Cannot call CentralProfiles.makeReservation: guestID + " + guestID +
                    " not found in GuestDatabase");
            return null;
        }

        RentableRoom room;
        Reservation myReservation;
        String reservationID;
        try {
            Method generateReservationID = Marsha.class.getDeclaredMethod("generateReservationID");
            generateReservationID.setAccessible(true);
            reservationID = generateReservationID.invoke(MARSHA).toString();
        }
        catch (Exception e) {
            MyLogger.logger.log(Level.SEVERE, "Error in CentralProfiles.makeReservation: cannot invoke Marsha");
            return null;
        }

        if((room = CentralRoom.getRoom(roomID)) == null) {
            MyLogger.logger.log(Level.SEVERE, "Error in CentralProfiles.makeReservation: room is null");
            return null;
        }

        try {
            roomID = room.getRoomID();
            myReservation = new Reservation(reservationID, guestID, roomID, startDate, endDate);

            Method addReservation = ReservationDatabase.class.getDeclaredMethod("addReservation", String.class, Reservation.class);
            addReservation.setAccessible(true);
            addReservation.invoke(RESERVATION_DATABASE, reservationID, myReservation);
        }
        catch (Exception e) {
            MyLogger.logger.log(Level.SEVERE, "Error in CentralProfiles.makeReservation: cannot make reservation");
            return null;
        }
        return reservationID;
    }
}
