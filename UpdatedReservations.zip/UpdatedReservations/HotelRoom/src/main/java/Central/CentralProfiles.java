package Central;

import AccountService.Arlow;
import AccountService.Employee;
import AccountService.Guest;
import Databases.EmployeeDatabase;
import Databases.GuestDatabase;
import LoggerPackage.MyLogger;
import Room.RoomInitializer;

import java.lang.reflect.Method;
import java.util.logging.Level;

public class CentralProfiles {
    private static final Arlow ARLOW = new Arlow();
    private static final GuestDatabase GUEST_DATABASE = new GuestDatabase();
    private static final EmployeeDatabase EMPLOYEE_DATABASE = new EmployeeDatabase();
    public static String makeGuestProfile(String firstName, String lastName,
                                          String email, String phoneNumber,
                                          String username, String password ) {
        try {
            Method generateGuestID = Arlow.class.getDeclaredMethod("generateGuestID");
            generateGuestID.setAccessible(true);
            String guestID = generateGuestID.invoke(ARLOW).toString();

            Method addGuest = GuestDatabase.class.getDeclaredMethod("addGuest", Guest.class);
            addGuest.setAccessible(true);
            addGuest.invoke(GUEST_DATABASE, new Guest(guestID, firstName, lastName, email, phoneNumber, username, password));

            return guestID;
        }
        catch (Exception e) {
            MyLogger.logger.log(Level.SEVERE, "Error caught in CentralProfiles.makeGuestProfile: " +
                    "Values passed were " + firstName + "," + lastName + "," + email + "," +
                    phoneNumber + "," + username + "," + password);
            return null;
        }
    }
    public static String makeEmployeeProfile(String firstName, String lastName,
                                             String email, String phoneNumber,
                                             String username, String password ) {
        try {
            Method generateEmployeeID = Arlow.class.getDeclaredMethod("generateEmployeeID");
            generateEmployeeID.setAccessible(true);
            String employeeID = generateEmployeeID.invoke(ARLOW).toString();

            Method addEmployee = EmployeeDatabase.class.getDeclaredMethod("addEmployee", Employee.class);
            addEmployee.setAccessible(true);
            addEmployee.invoke(EMPLOYEE_DATABASE, new Employee(employeeID, firstName, lastName, email, phoneNumber, username, password));

            return employeeID;
        }
        catch (Exception e) {
            MyLogger.logger.log(Level.SEVERE, "Error caught in CentralProfiles.makeEmployeeProfile: " +
                    "Values passed were " + firstName + "," + lastName + "," + email + "," +
                    phoneNumber + "," + username + "," + password);
            return null;
        }
    }
}
