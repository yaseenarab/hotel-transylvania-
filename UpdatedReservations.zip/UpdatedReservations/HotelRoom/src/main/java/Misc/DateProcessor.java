package Misc;

import LoggerPackage.MyLogger;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;

public class DateProcessor {
    private static final SimpleDateFormat SDF = new SimpleDateFormat("MM/dd/yyyy");
    public static Date stringToDate(String date) {
        try {
            Date myDate = SDF.parse(date);
            return myDate;
        }
        catch (Exception e) {
            MyLogger.logger.log(Level.SEVERE, "Error caught in DateProcessor.stringToDate: cannot " +
                    "parse date, passed value was " + date);
            return null;
        }
    }
}
