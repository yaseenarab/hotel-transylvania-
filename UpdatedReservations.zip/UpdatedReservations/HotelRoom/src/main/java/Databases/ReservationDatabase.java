package Databases;

import AccountService.Guest;
import Room.Reservation;
import java.util.Map;
import java.util.TreeMap;

public class ReservationDatabase {
    private static Map<String, Reservation> reservations = new TreeMap<>();
    private static void addReservation(String reservationID, Reservation reservation) {
        reservations.put(reservationID, reservation);
    }
    private static Reservation getReservation(String reservationID) {
        try {
            return reservations.get(reservationID);
        }
        catch (Exception e) {
            return null;
        }
    }
    public static boolean isIDUnique(String reservationID) {
        return !(reservations.containsKey(reservationID));
    }
}
