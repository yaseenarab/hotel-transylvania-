package Databases;

import AccountService.Guest;

import java.util.Map;
import java.util.TreeMap;

public class MemberDatabase {
    private static Map<String, Guest> members = new TreeMap<>();
    private static void addGuest(Guest guest) {
        members.put(guest.getGuestID(), guest);
    }
    private static Guest getGuest(String guestID) {
        return members.get(guestID);
    }
    public static boolean isIDStored(String guestID) {
        try {
            Boolean found = members.containsKey(guestID);
            return found;
        }
        catch (Exception e) {
            return false;
        }
    }
}
