package Databases;

import AccountService.Guest;
import java.util.Map;
import java.util.TreeMap;

public class GuestDatabase {
    private static Map<String, Guest> guests = new TreeMap<>();
    private void addGuest(Guest guest) {
        guests.put(guest.getGuestID(), guest);
    }
    private Guest getGuest(String guestID) {
        return guests.get(guestID);
    }
    public static boolean isIDStored(String guestID) {
        try {
            Boolean found = guests.containsKey(guestID);
            return found;
        }
        catch (Exception e) {
            return false;
        }
    }
}
