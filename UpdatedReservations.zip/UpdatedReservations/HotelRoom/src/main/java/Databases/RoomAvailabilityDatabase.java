package Databases;

import Room.RentableRoom;
import Room.Reservation;
import Room.RoomData;

import java.util.Map;
import java.util.TreeMap;

public class RoomAvailabilityDatabase implements RoomData {
    private static Map<String, RentableRoom> rooms = new TreeMap<>();
    private static void addRoom(String roomID, RentableRoom room) {
        rooms.put(roomID, room);
    }
    private static RentableRoom getRoom(String roomID) {
        for(String ID : rooms.keySet()) {
            if(ID.substring(0, SMOKING_STATUS + 1).contains(roomID.substring(0, SMOKING_STATUS + 1)))
                return rooms.get(ID);
        }
        return null;
    }
}
