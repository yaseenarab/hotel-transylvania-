package UI.Panels;

import javax.swing.*;

// Panel for finalizing items in cart to add to final bill
public class ShoppingCheckoutPanel extends JPanel {
    private JPanel content;

    public ShoppingCheckoutPanel(ShoppingMainPanel shoppingPanel) {

    }
}
