package Hotel.DataBaseManipulation;

import javax.swing.plaf.nimbus.State;
import java.sql.*;

public class DataGetSet {

    final private String DB_URLRes = "jdbc:derby:ReservationsData;";
    final private String DB_URLPer = "jdbc:derby:PersonProfilesData;";
    final private String DB_URLHot = "jdbc:derby:HotelRoomsData;";
    private Connection conRes;
    private Connection conPer;
    private Connection conHot;

    public DataGetSet() throws SQLException {
        conHot = DriverManager.getConnection(DB_URLHot);
        conPer = DriverManager.getConnection(DB_URLPer);
        conRes = DriverManager.getConnection(DB_URLRes);

    }

    public Connection getConHottelRoomsDatabase() {
        return conHot;
    }

    public Connection getConReservationDatabase() {
        return conRes;
    }

    public Connection getConPersonProfileDataBase() {
        return conPer;
    }


    public void insertIntoPersonProfiles(String line)  {
        try {
            Statement stmt = conPer.createStatement();
            String [] split = line.split(",");
            stmt.executeUpdate("insert into PersonProfiles(PersonId, FirstName,LastName,Email, PhoneNumber,Username,Password) values('" +split[0] + "','" + split[1] + "','"+ split[2]+ "','" + split[3] + "','" + split[4] + "','" + split[5] + "','" + split[6]  +"')");

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void insertIntoHotelRoomsData(String line) {
        try {
            Statement stmt = conPer.createStatement();
            String [] split = line.split(",");
            stmt.executeUpdate("insert into PersonProfiles(PersonId, FirstName,LastName,Email, PhoneNumber,Username,Password) values('" +split[0] + "','" + split[1] + "','"+ split[2]+ "','" + split[3] + "','" + split[4] + "','" + split[5] + "','" + split[6]  +"')");

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void insertIntoReservations(String line)  {
        try {
            Statement stmt = conRes.createStatement();
            String [] split = line.split(",");
            stmt.executeUpdate("insert into Reservations(RoomNumber, Username,StartDate, EndDate) values('" +split[0] + "','" + split[1] + "','"+ split[2]+ "','" + split[3] +"')");

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

}
