package Hotel.Central;

//import Hotel.Databases.RoomAvailabilityDatabase;
//import Hotel.Databases.RoomCostDatabase;
import Hotel.Room.RentableRoom;
import Hotel.LoggerPackage.MyLogger;
import Hotel.Room.RentableRoom;
import Hotel.Room.RoomInitializer;

import java.lang.reflect.Method;
import java.util.logging.Level;

public class CentralRoom {

    private static boolean roomsInitialized;
    private static final RoomInitializer ROOM_INITIALIZER = new RoomInitializer();
    //private static final RoomAvailabilityDatabase ROOM_AVAILABILITY_DATABASE = new RoomAvailabilityDatabase();
    //private static final RoomCostDatabase ROOM_COST_DATABASE = new RoomCostDatabase();

    public static boolean initializeRooms(Integer numFloors, Integer numRooms) {
        /*
        try {
            Method initRooms = RoomInitializer.class.getDeclaredMethod("initRooms", Integer.class, Integer.class);
            initRooms.setAccessible(true);
            initRooms.invoke(ROOM_INITIALIZER,numFloors, numRooms);

            roomsInitialized = true;
        }
        catch (Exception e) {
            roomsInitialized = false;
        }


         */
        return roomsInitialized;
    }

    public static void addRoom(String roomID, RentableRoom room) {

        try {
            //Method addRoom = RoomAvailabilityDatabase.class.getDeclaredMethod("addRoom", String.class, RentableRoom.class);
            //addRoom.setAccessible(true);
            //addRoom.invoke(ROOM_AVAILABILITY_DATABASE, roomID, room);
        } catch (Exception e) {
            MyLogger.logger.log(Level.SEVERE, "Error caught in CentralReservations.addRoom: " +
                    "Values passed were " + roomID + "," + room);
        }


    }

    public static Integer quoteRoom(Integer roomID, String guestID) {

        try {
            //Method calculateDailyRate = RoomCostDatabase.class.getDeclaredMethod("calculateDailyRate", String.class, String.class);
            //calculateDailyRate.setAccessible(true);
            //return ((Integer)(calculateDailyRate.invoke(ROOM_COST_DATABASE, roomID, guestID)));
        } catch (Exception e) {
            MyLogger.logger.log(Level.SEVERE, "Error caught in CentralReservations.quoteRoom: " +
                    "Values passed were " + roomID + "," + guestID);
            return null;
        }


        return 1;
    }

    public static RentableRoom getRoom(String roomID) {
        try {
            //Method getRoom = RoomAvailabilityDatabase.class.getDeclaredMethod("getRoom", String.class);
            //getRoom.setAccessible(true);
            //return ((RentableRoom)getRoom.invoke(ROOM_AVAILABILITY_DATABASE, roomID));
        } catch (Exception e) {
            MyLogger.logger.log(Level.SEVERE, "Error caught in CentralReservations.getRoom: " +
                    "Values passed was " + roomID);
            return null;
        }
        return null;
    }

}
