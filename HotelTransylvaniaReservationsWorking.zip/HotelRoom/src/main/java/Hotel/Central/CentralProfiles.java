package Hotel.Central;

import Hotel.AccountService.Arlow;
import Hotel.AccountService.Guest;
import Hotel.DataBaseManipulation.DataGetSet;
//import Hotel.Databases.EmployeeDatabase;
//import Hotel.Databases.GuestDatabase;
import Hotel.LoggerPackage.MyLogger;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;

public class CentralProfiles {
    private static final Arlow ARLOW = new Arlow();



    public static Guest getGuest(String username, String password) {

        Guest guest = null;
        try {
            DataGetSet d = new DataGetSet();
            Connection con = d.getConPersonProfileDataBase();
            Statement stmt = con.createStatement();
            ResultSet res = stmt.executeQuery("SELECT * FROM personprofiles WHERE Username = '" + username + "' And password = '" + password + "'");

            if(res.next()){
                String guestId = res.getString("personid");
                String firstName = res.getString("firstname");
                String lastName = res.getString("lastname");
                String email = res.getString("email");
                String phonenumber = res.getString("phonenumber");
                guest = new Guest(guestId,firstName,lastName,email,phonenumber,username,password);

            }


        }
        catch (Exception e) {
            e.printStackTrace();
            MyLogger.logger.log(Level.SEVERE, "Error caught in CentralProfiles.getGuest: ");
            return null;
        }
        return guest;
    }

    public static Boolean guestisIn(String username, String password, String email, String phoneNumber) {

        Guest guest = null;
        try{
            DataGetSet d = new DataGetSet();
            Connection con = d.getConPersonProfileDataBase();
            Statement stmt = con.createStatement();

            ResultSet res = stmt.executeQuery("Select * from PersonProfiles where Username = '" + username+"'");
            if(res.next()){
                return true;
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return false;
    }
    public static String makeGuestProfile(String firstName, String lastName,
                                          String email, String phoneNumber,
                                          String username, String password ) {
        try {
            DataGetSet d = new DataGetSet();
            Connection con = d.getConPersonProfileDataBase();
            Statement stmt = con.createStatement();
            ResultSet res = stmt.executeQuery("SELECT * FROM personprofiles WHERE personid=(SELECT max(Personid) FROM Personprofiles)");

            Integer idNum;
            if(res.next()){
                String idStr = res.getString("PersonId");
                idNum = Integer.parseInt( idStr.substring(4,idStr.length()));
            }
            else{
                idNum = 1000000000;
            }

            String guestID = Arlow.generateGuestID(idNum);
            stmt.executeUpdate("INSERT INTO PersonProfiles(PersonId,firstname,lastname,email,Phonenumber,Username,password) values ('"+guestID + "','"+firstName + "','" +lastName + "','" + email + "','" + phoneNumber + "','" + username + "','" + password+ "')");


            return "guestID";
        }
        catch (Exception e) {
            e.printStackTrace();
            MyLogger.logger.log(Level.SEVERE, "Error caught in CentralProfiles.makeGuestProfile: " +
                    "Values passed were " + firstName + "," + lastName + "," + email + "," +
                    phoneNumber + "," + username + "," + password);
            return null;
        }
    }
    public static String makeEmployeeProfile(String firstName, String lastName,
                                             String email, String phoneNumber,
                                             String username, String password ) {
        try {
            DataGetSet d = new DataGetSet();
            Connection con = d.getConPersonProfileDataBase();
            Statement stmt = con.createStatement();
            ResultSet res = stmt.executeQuery("SELECT * FROM personprofiles WHERE personid=(SELECT max(Personid) FROM Personprofiles)");

            Integer idNum;
            if(res.next()){
                String idStr = res.getString("PersonId");
                idNum = Integer.parseInt( idStr.substring(4,idStr.length()));
            }
            else{
                idNum = 1000000000;
            }

            String employeeId = Arlow.generateEmployeeID(idNum);
            stmt.executeUpdate("INSERT INTO PersonProfiles(PersonId,firstname,lastname,email,Phonenumber,Username,password) values ('"+ employeeId + "','"+firstName + "','" +lastName + "','" + email + "','" + phoneNumber + "','" + username + "','" + password+ "')");

            return "employeeID";
        }
        catch (Exception e) {
            MyLogger.logger.log(Level.SEVERE, "Error caught in CentralProfiles.makeEmployeeProfile: " +
                    "Values passed were " + firstName + "," + lastName + "," + email + "," +
                    phoneNumber + "," + username + "," + password);
            return null;
        }
    }
}
