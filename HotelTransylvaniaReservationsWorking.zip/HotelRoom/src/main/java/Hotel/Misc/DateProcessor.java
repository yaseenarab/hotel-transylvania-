package Hotel.Misc;

import Hotel.LoggerPackage.MyLogger;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;

public class DateProcessor {
    private static final SimpleDateFormat SDF = new SimpleDateFormat("MM/dd/yyyy");
    public static Date stringToDate(String date) {
        try {
            Date myDate = SDF.parse(date);
            return myDate;
        }
        catch (Exception e) {
            MyLogger.logger.log(Level.SEVERE, "Error caught in DateProcessor.stringToDate: cannot " +
                    "parse date, passed value was " + date);
            return null;
        }
    }


    public static String dateToString(Date date) {
        try {
            String myDate = SDF.format(date);
            return myDate;
        }
        catch (Exception e) {
            MyLogger.logger.log(Level.SEVERE, "Error caught in DateProcessor.stringToDate: cannot " +
                    "parse date, passed value was " + date);
            return null;
        }
    }

    public static boolean isOverlapUsingCalendarAndDuration(Calendar start1, Calendar end1, Calendar start2, Calendar end2) {
        long overlap = Math.min(end1.getTimeInMillis(), end2.getTimeInMillis()) -
                Math.max(start1.getTimeInMillis(), start2.getTimeInMillis());
        System.out.println(overlap);
        return overlap >= 0;
    }



}
