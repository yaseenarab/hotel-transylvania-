package Hotel.AccountService;

import Hotel.LoggerPackage.MyLogger;
import Hotel.Room.Reservation;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;

public class Guest extends Person {
    private String guestID;
    private Map<String, Reservation> reservations = new HashMap<>();


    public Guest(String guestID, String firstName, String lastName, String email, String phoneNumber, String username, String password) throws Exception {
        super(firstName, lastName, email, phoneNumber, username, password);
        try {
            this.setGuestID(guestID);
        }
        catch (Exception e) {
            MyLogger.logger.log(Level.SEVERE, "Error caught in Guest constructor: Passed values were " +
                    guestID + "," + firstName + "," + lastName + "," + email + "," + phoneNumber + "," +
                    username + "," + password);
            throw new Exception();
        }
    }
    private void setGuestID(String guestID) throws Exception {
        if(guestID == null) {
            MyLogger.logger.log(Level.SEVERE, "Error in Guest.setGuestID: guestID is null");
            throw new Exception();
        }
        else if(guestID.length() != Arlow.GUEST_ID_LENGTH ) {
            MyLogger.logger.log(Level.SEVERE, "Error in Guest.setGuestID: guestID should be " +
                    Arlow.GUEST_ID_LENGTH + " characters, found " + guestID.length() + ", received " + guestID);
            throw new Exception();
        }
        this.guestID = guestID;
    }

    public Map<String,Reservation> getReservations() {
        return reservations;
    }

    public void setReservations(Map<String, Reservation> reservations) {
        this.reservations = reservations;
    }

    public void addReservation(Reservation r){
        reservations.put(r.getReservationID(),r);
    }
    public String getGuestID() {
        return this.guestID;
    }
    public String toString() {
        return this.guestID + "," + super.toString();
    }
}
