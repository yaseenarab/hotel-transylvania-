package Hotel.UI;

import Hotel.AccountService.Guest;
import Hotel.Central.CentralReservations;
import Hotel.DataBaseManipulation.DataGetSet;
import Hotel.Misc.DateProcessor;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableRowSorter;

import java.awt.*;

import java.sql.*;
import java.util.Date;


public class AvailableRoomsPanel extends JPanel {

    private TableRowSorter<DefaultTableModel> sorter;
    private DefaultTableModel model;
    private Guest guest;
    private JTable table;
    private JLabel noRooms;
    private Integer id;
    private JScrollPane scrollPane;
    private Date start,end;
    AvailableRoomsPanel(Guest guest ) {


        super();
        this.guest = guest;
        this.end = end;
        this.setLayout(new BorderLayout());
        //this.setLayout(null);
        model = new DefaultTableModel();
        //reservationSummary = new JLabel();


        noRooms = new JLabel("<html>No Rooms Available</html>");
        noRooms.setFont(new Font("Serif", Font.ITALIC, 55));
        noRooms.setPreferredSize(new Dimension( 500,200));

        model.addColumn("Room ID");
        model.addColumn("Room Status");
        model.addColumn("Room Type");
        model.addColumn("Bed Type");
        model.addColumn("Quality Level");
        model.addColumn("Smoking Allowed");
        table = new JTable(model);
        //table.setPreferredSize(new Dimension(300,300));
        table.setRowHeight(15);

        TableColumnModel columnModel = table.getColumnModel();
        columnModel.getColumn(0).setPreferredWidth(40);
        columnModel.getColumn(1).setPreferredWidth(65);
        columnModel.getColumn(2).setPreferredWidth(60);
        columnModel.getColumn(3).setPreferredWidth(30);
        //columnModel.getColumn(4).setPreferredWidth(100);
        //columnModel.getColumn(5).setPreferredWidth(120);



        table.setAutoCreateRowSorter(true);

        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.getSelectionModel().addListSelectionListener(this::valueChanged);

        scrollPane = new JScrollPane(table);
        scrollPane.setVisible(true);
        //scrollPane.setSize(new Dimension(480, 100));

        //

        add(scrollPane,BorderLayout.CENTER);
        add(noRooms,BorderLayout.SOUTH);



    }

    public boolean roomIsSelected() {

        return table.getSelectedRow() > -1;

    }

    public void updateTable(String SQL, Date start, Date end){
        scrollPane.setVisible(true);

        id = null;

        this.start = start;
        this.end = end;

        if (model.getRowCount() > 0) {
            for (int i = model.getRowCount() - 1; i > -1; i--) {
                model.removeRow(i);
            }
        }

        try {
            CentralReservations.putValues(SQL,model);


            if(model.getRowCount() == 0){
                throw new SQLException();
            }

            noRooms.setText("");

        }catch (SQLException e) {
            e.printStackTrace();

            noRooms.setFont(new Font("Serif", Font.ITALIC, 55));
            noRooms.setText("<html>No Rooms Available</html>");
            //scrollPane.setVisible(false);

        }
    }


    public void valueChanged(ListSelectionEvent event) {
        int viewRow = table.getSelectedRow();

        if(viewRow >= 0){
            int modelRow = table.convertRowIndexToModel(viewRow);
            String idStr = (String) model.getValueAt(modelRow, 0);
            id = Integer.parseInt(idStr);
            displayReservationSummary();
        }
    }

    public void displayReservationSummary(){


        String startStr = DateProcessor.dateToString(start);
        String endStr = DateProcessor.dateToString(end);
        noRooms.setFont(new Font("a", Font.BOLD,15));
        noRooms.setLayout(null);

        noRooms.setText("<html>Reservation Summary: <br/> Name: "+ guest.getFirstName() + " <br/>Last Name: " + guest.getLastName() +
                "<br/>Username: " + guest.getUsername()+ " <br/>Room ID: " + id +"  <br/> Start Date:  " + startStr + "<br/>End Date: " + endStr+
                "<br/>Cost: </html>");


    }

    public Integer getRoomID() {
        return id;
    }
}
