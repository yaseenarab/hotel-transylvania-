//import Hotel.Central.CentralRoom;
//import Hotel.Central.CentralRoomID;
//import Hotel.Central.CentralReservations;
import Hotel.Central.CentralRoom;
import Hotel.UI.LoginFrame;

//import static Hotel.Central.CentralRoom.initializeRooms;

public class Main {
    public static void main(String[] args) {

        System.out.println(CentralRoom.calculatorCost(101));
        //CentralProfiles.getEmployeeProfiles();
        
        LoginFrame login = new LoginFrame();

        login.setVisible(true);
    }


}
