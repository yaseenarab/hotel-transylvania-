package Hotel.Central;

import Hotel.AccountService.Admin;
import Hotel.AccountService.Arlow;
import Hotel.AccountService.Employee;
import Hotel.AccountService.Guest;
//import Hotel.Databases.EmployeeDatabase;
//import Hotel.Databases.GuestDatabase;
import Hotel.LoggerPackage.MyLogger;

import javax.print.attribute.standard.DateTimeAtProcessing;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;

public class CentralProfiles {
    private static final Arlow ARLOW = new Arlow();
    public static Guest getGuest(String username, String password) {
        Guest guest = null;
        try {
            ResultSet guestData = CentralDatabase.getGuest(username);

            if(guestData.next()){
                String guestId = guestData.getString("personid");
                String firstName = guestData.getString("firstname");
                String lastName = guestData.getString("lastname");
                String email = guestData.getString("email");
                String phonenumber = guestData.getString("phonenumber");
                guest = new Guest(guestId,firstName,lastName,email,phonenumber,username,password);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
            MyLogger.logger.log(Level.SEVERE, "Error caught in CentralProfiles.getGuest: ");
            return null;
        }
        return guest;
    }

    public static String getGuestID(String username) {
        try {
            ResultSet guestData = CentralDatabase.getGuest(username);

            if(guestData.next()){
                String guestId = guestData.getString("personid");
                return guestId;
            }
        }
        catch (Exception e) {
            e.printStackTrace();
            MyLogger.logger.log(Level.SEVERE, "Error caught in CentralProfiles.getGuest: ");
            return null;
        }
        return null;
    }


    public static Boolean authenticateUser(String username, String password, String type) {
        String SQL = null;
        Connection con = null;
        ResultSet person = null;
        try{

            if(type.equals("Guest")) {
                person = CentralDatabase.getPerson(username);
            }
            else if(type.equals("Employee")){
                person = CentralDatabase.getEmployee(username);

            }
            else if(type.equals("Admin")){
                person = CentralDatabase.getAdmin(username);
            }

            if(person.next()){
                return true;
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return false;
    }
    public static String makeGuestProfile(String firstName, String lastName,
                                          String email, String phoneNumber,
                                          String username, String password ) {
        try {
            ResultSet idSet = CentralDatabase.getGuestMaxID();

            Integer idNum;
            if(idSet.next()) {
                String idStr = idSet.getString("PersonId");
                idNum = Integer.parseInt( idStr.substring(4,idStr.length()));
            }
            else{
                idNum = 1000000000;
            }
            CentralDatabase.insertIntoPersonProfiles(Arlow.generateGuestID(idNum) + "," + firstName + "," + lastName + "," +
                    email + "," + phoneNumber + "," + username + "," + password);

            return "guestID";
        }
        catch (Exception e) {
            e.printStackTrace();
            MyLogger.logger.log(Level.SEVERE, "Error caught in CentralProfiles.makeGuestProfile: " +
                    "Values passed were " + firstName + "," + lastName + "," + email + "," +
                    phoneNumber + "," + username + "," + password);
            return null;
        }
    }

    public static Employee getEmployee(String username, String password){
        Employee employee = null;
        try {
            ResultSet empSet = CentralDatabase.getEmployee(username);

            while(empSet.next()){

                String employeeId = empSet.getString("PERSONID");
                String firstName = empSet.getString("FIRSTNAME");
                String lastName = empSet.getString("LASTNAME");
                String email = empSet.getString("EMAIL");
                String phoneNumber = empSet.getString("PHONENUMBER");

                employee = new Employee(employeeId,firstName,lastName,email,phoneNumber,username,password);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return employee;
    }
    public static Admin getAdmin(String username, String password){

        Admin admin = null;
        try {
            ResultSet adSet = CentralDatabase.getAdmin(username);
            while(adSet.next()){

                String adminId = adSet.getString("personid");
                String firstName = adSet.getString("firstname");
                String lastName = adSet.getString("lastname");
                String email = adSet.getString("email");
                String phonenumber = adSet.getString("phonenumber");

                admin = new Admin(adminId,firstName,lastName,email,phonenumber,username,password);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return admin;
    }
    public static String makeEmployeeProfile(String firstName, String lastName,
                                             String email, String phoneNumber,
                                             String username, String password ) {
        try {
            ResultSet res = CentralDatabase.getEmployeeMaxID();

            Integer idNum;
            if(res.next()){
                String idStr = res.getString("PersonId");
                idNum = Integer.parseInt( idStr.substring(4,idStr.length()));
            }
            else{
                idNum = 1000000000;
            }
            CentralDatabase.insertIntoEmployeeProfiles(Arlow.generateEmployeeID(idNum) + "," + firstName + "," + lastName + "," + email + "," + phoneNumber + "," + username + "," + password);
            return "employeeID";
        }
        catch (Exception e) {
            MyLogger.logger.log(Level.SEVERE, "Error caught in CentralProfiles.makeEmployeeProfile: " +
                    "Values passed were " + firstName + "," + lastName + "," + email + "," +
                    phoneNumber + "," + username + "," + password);
            return null;
        }
    }

    public static boolean AdminisIn(String username) {
        try{
            ResultSet ad = CentralDatabase.getAdmin(username);
            if(ad.next()){
                return true;
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return false;

    }

    public static String makeAdminProfile(String firstName, String lastName, String email, String phoneNumber, String username, String password) {
        try {
            ResultSet res = CentralDatabase.getAdminMaxID();

            Integer idNum;
            if(res.next()){
                String idStr = res.getString("PersonId");
                idNum = Integer.parseInt( idStr.substring(4,idStr.length()));
            }
            else{
                idNum = 1000000000;
            }

            CentralDatabase.insertIntoAdminProfiles(Arlow.gerenateAdminId(idNum) + firstName + "," + lastName + "," + email + "," + phoneNumber + "," + username + "," + password);
            return "adminID";
        }
        catch (Exception e) {
            MyLogger.logger.log(Level.SEVERE, "Error caught in CentralProfiles.makeEmployeeProfile: " +
                    "Values passed were " + firstName + "," + lastName + "," + email + "," +
                    phoneNumber + "," + username + "," + password);
            return null;
        }
    }
}
