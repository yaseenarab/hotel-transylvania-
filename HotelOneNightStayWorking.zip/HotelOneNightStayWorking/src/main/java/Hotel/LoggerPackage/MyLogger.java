package Hotel.LoggerPackage;

public class MyLogger {
    public static java.util.logging.Logger logger =
            java.util.logging.Logger.getLogger(MyLogger.class.getName());
}
