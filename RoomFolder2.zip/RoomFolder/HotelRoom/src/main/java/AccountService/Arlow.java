package AccountService;
public class Arlow {
    public static final int GUEST_ID_LENGTH = 14, EMPLOYEE_ID_LENGTH = 14;
    private static Integer guestIDNum = 1000000000, employeeIDNum = 1000000000;
    private static String generateGuestID() {
        String guestID = "TVGI";

        if (guestIDNum >= 2147483647) {
            guestIDNum = 1000000000;
        }
        return guestID + guestIDNum++;
    }
    private static String generateEmployeeID() {
        String employeeID = "TVEI";

        if (employeeIDNum >= 2147483647) {
            employeeIDNum = 1000000000;
        }
        return employeeID + employeeIDNum++;
    }
}
