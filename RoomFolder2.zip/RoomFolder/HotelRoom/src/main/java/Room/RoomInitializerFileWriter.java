package Room;

public class RoomInitializerFileWriter extends RoomInitializer {
    public void writeRoomsToFile() {

        for(int i = 0; i < RoomInitializer.numFloors; ++i) {
            for(int j = 0; j < RoomInitializer.roomsPerFloor; ++j) {

            }
        }
    }
}
