import Central.CentralProfiles;
import Central.CentralRoom;
import Central.CentralRoomID;
import Central.CentralReservations;
import LoggerPackage.MyLogger;
import Misc.DateProcessor;
import Room.Reservation;
import java.util.Date;
import java.util.logging.Level;

public class Main {
    public static void main(String[] args) {
        int numFloors = 3, numRooms = 36;

        if(!CentralRoom.initializeRooms(numFloors, numRooms)) {
            MyLogger.logger.log(Level.SEVERE, "Failed to initialize rooms. Exiting program");
            System.exit(1);
        }
        String myID = CentralProfiles.makeGuestProfile(
                "Mitchell", "Thompson", "MDT2001@icloud.com",
                "9497690969", "username", "password");
        if(myID != null) {
            System.out.println(myID);
        }

        String roomID = CentralRoomID.createRoomID("nature", "single", "economy",false);
        if(roomID != null) {
            System.out.println(roomID);
        }

        Date startDate = DateProcessor.stringToDate("04/22/24");
        Date endDate = DateProcessor.stringToDate("4/25/24");

        Integer cost = CentralRoom.quoteRoom(roomID, myID);
        if(cost != null) {
            System.out.println(cost);
        }

        String reservationID = CentralReservations.makeReservation(roomID, myID, startDate, endDate);
        if(reservationID != null) {
            System.out.println(reservationID);
        }

        Reservation myReservation = CentralReservations.getReservation(reservationID);
        if(myReservation != null) {
            System.out.println(myReservation.getRoomCost());
            System.out.println(myReservation.getRoomID());
        }

    }
}
