package Databases;

import AccountService.Card;
import java.util.Map;
import java.util.TreeMap;

public class CardDatabase {
    private static Map<String, Card> cards = new TreeMap<>();
    private static void addCard(String guestID, Card card) {
        cards.put(guestID, card);
    }
    private static Card getCard(String guestID) {
        return cards.get(guestID);
    }
    private static boolean isCardUnique(String guestID) {
        return !(cards.containsKey(guestID));
    }
}
