package Databases;

import AccountService.Employee;
import java.util.Map;
import java.util.TreeMap;

public class EmployeeDatabase {
    private static Map<String, Employee> employees = new TreeMap<>();
    private static void addEmployee(Employee employee) {
        employees.put(employee.getEmployeeID(), employee);
    }
    private static Employee getEmployee(String employeeID) {
        return employees.get(employeeID);
    }
    private static boolean isIDUnique(String employeeID) {
        return !(employees.containsKey(employeeID));
    }
}
