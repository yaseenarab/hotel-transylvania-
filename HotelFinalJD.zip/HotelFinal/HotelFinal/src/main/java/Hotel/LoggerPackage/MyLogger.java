package Hotel.LoggerPackage;

/**
 * Provides a centralized logger for the application.
 * Utilizes java.util.logging.Logger to log various levels of information and errors.
 */
public class MyLogger {
    /**
     * Static instance of java.util.logging.Logger configured to the name of this class.
     * This logger is used throughout the application to log messages, warnings, and errors.
     */
    public static java.util.logging.Logger logger =
            java.util.logging.Logger.getLogger(MyLogger.class.getName());
}