package Hotel.Central;

import Hotel.Enums.BedType;
import Hotel.Enums.QualityLevel;
import Hotel.Enums.RoomStatus;
import java.sql.*;

/**
 * Centralized database management class for handling all database operations
 * within the hotel management system. This class establishes connections to multiple
 * databases and provides methods to interact with these databases effectively.
 */
public class CentralDatabase {
    // Database connection strings for various parts of the system
    private static final String DB_URLRes = "jdbc:derby:ReservationsData;";
    private static final String DB_URLPer = "jdbc:derby:PersonProfilesData;";
    private static final String DB_URLEmployee = "jdbc:derby:EmployeeProfilesData;";
    private static final String DB_URLAdmin = "jdbc:derby:AdminProfilesData;";
    private static final String DB_URLHot = "jdbc:derby:HotelRoomsData;";
    private static final String DB_URLCash = "jdbc:derby:CashieringData;";
    private static final String DB_URLCart = "jdbc:derby:ShoppingCartData";
    private static final String DB_URLCatalogue = "jdbc:derby:CatalogueDatabase";

    // Static variables for database connections
    private static Connection conRes;
    private static Connection conGuest;
    private static Connection conEmployee;
    private static Connection conAdmin;
    private static Connection conHot;
    private static Connection conCash;
    private static Connection conCart;
    private static Connection conCatalogue;

    /**
     * Initializes connections to all specified databases.
     *
     * @return true if all connections are successfully established, false otherwise.
     */
    public static boolean init() {
        try {
            conRes = DriverManager.getConnection(DB_URLRes);
            conGuest = DriverManager.getConnection(DB_URLPer);
            conEmployee = DriverManager.getConnection(DB_URLEmployee);
            conAdmin = DriverManager.getConnection(DB_URLAdmin);
            conHot = DriverManager.getConnection(DB_URLHot);
            conCash = DriverManager.getConnection(DB_URLCash);
            conCart = DriverManager.getConnection(DB_URLCart);
            conCatalogue = DriverManager.getConnection(DB_URLCatalogue);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Gets the connection object for the hotel rooms database.
     *
     * @return Connection object connected to the hotel rooms database.
     */
    public static Connection getConHotelRoomsDatabase() {
        return conHot;
    }

    /**
     * Gets the connection object for the reservations database.
     *
     * @return Connection object connected to the reservations database.
     */
    public static Connection getConReservationDatabase() {
        return conRes;
    }

    /**
     * Gets the connection object for the guest profiles database.
     *
     * @return Connection object connected to the guest profiles database.
     */
    public static Connection getConGuestProfileDataBase() {
        return conGuest;
    }

    /**
     * Gets the connection object for the employee profiles database.
     *
     * @return Connection object connected to the employee profiles database.
     */
    public static Connection getConEmployeeProfileDataBase() {
        return conEmployee;
    }

    /**
     * Gets the connection object for the admin profiles database.
     *
     * @return Connection object connected to the admin profiles database.
     */
    public static Connection getConAdminProfileDataBase() {
        return conAdmin;
    }

    /**
     * Gets the connection object for the cashiering database.
     *
     * @return Connection object connected to the cashiering database.
     */
    public static Connection getConCashieringDatabase() {
        return conCash;
    }

    /**
     * Retrieves the first name of the guest based on the username from the guest profiles database.
     *
     * @param username The username to look up.
     * @return The first name of the guest if found, null otherwise.
     */
    public static String getGuest(String username) {
        ResultSet resultSet = null;
        try {
            Statement statement = conGuest.createStatement();
            resultSet = statement.executeQuery("SELECT * FROM PERSONPROFILES WHERE USERNAME = '" + username + "'");
            if (resultSet.next()) {
                return resultSet.getString("FIRSTNAME");
            }
        } catch (Exception e) {
            System.out.println("Error retrieving guest data");
        }
        return null;
    }

    /**
     * Retrieves the username associated with a room from the reservations database.
     *
     * @param roomNumber The room number to look up.
     * @return The username associated with that room if found, null otherwise.
     */
    public static String getUsernameFromRoom(int roomNumber) {
        ResultSet resultSet = null;
        try {
            Statement statement = conRes.createStatement();
            resultSet = statement.executeQuery("SELECT * FROM RESERVATIONS WHERE ROOMNUMBER = " + roomNumber);
            if (resultSet.next()) {
                return resultSet.getString("USERNAME");
            }
        } catch (Exception e) {
            System.out.println("Error retrieving username from room");
        }
        return null;
    }

    /**
     * Updates the card balance for a user in the cashiering database.
     *
     * @param username The username whose balance needs updating.
     * @param amount The amount to add to the current balance.
     */
    public static void updateCardBalance(String username, double amount) {
        try {
            ResultSet resultSet = null;
            Statement statement = conCash.createStatement();
            resultSet = statement.executeQuery("SELECT * FROM CASHIERINGDATA WHERE USERNAME = '" + username + "'");
            if (resultSet.next()) {
                int currentBalance = resultSet.getInt("RUNNINGBALANCE");
                PreparedStatement preparedStatement = conCash.prepareStatement("UPDATE CASHIERINGDATA SET RUNNINGBALANCE = ? WHERE USERNAME = ?");
                currentBalance += amount;
                preparedStatement.setInt(1, currentBalance);
                preparedStatement.setString(2, username);
                preparedStatement.executeUpdate();
            }
        } catch (Exception e) {
            System.out.println("Error updating card balance");
        }
    }

    /**
     * Retrieves reservation details for a specific room from the reservations database.
     *
     * @param roomNumber The room number to look up reservations for.
     * @return A ResultSet containing the reservation details, null if no reservation is found.
     */
    public static ResultSet getReservation(int roomNumber) {
        ResultSet resultSet = null;
        try {
            Statement statement = conRes.createStatement();
            resultSet = statement.executeQuery("SELECT * FROM RESERVATIONS WHERE ROOMNUMBER = " + roomNumber);
        } catch (Exception e) {
            System.out.println("Error retrieving reservation details");
        }
        return resultSet;
    }

    /**
     * Removes a specific reservation based on the room number from the reservations database.
     *
     * @param roomNumber The room number of the reservation to remove.
     */
    public static void removeReservation(int roomNumber) {
        try {
            Statement statement = conRes.createStatement();
            statement.execute("DELETE FROM RESERVATIONS WHERE ROOMNUMBER = " + roomNumber);
        } catch (Exception e) {
            System.out.println("Error removing reservation");
        }
    }

    /**
     * Checks in a guest by updating the check-in status in the reservations database.
     *
     * @param roomNumber The room number where the guest is checking in.
     */
    public static void checkIn(int roomNumber) {
        try {
            PreparedStatement preparedStatement = conRes.prepareStatement("UPDATE RESERVATIONS SET CHECKEDIN = ? WHERE ROOMNUMBER = ?");
            preparedStatement.setString(1, Boolean.toString(true));
            preparedStatement.setInt(2, roomNumber);
            preparedStatement.executeUpdate();
        } catch (Exception e) {
            System.out.println("Error during check-in");
        }
    }

    /**
     * Checks if a username is unique across all profile databases (guests, employees, admins).
     *
     * @param username The username to check for uniqueness.
     * @return true if the username is unique, false if it exists in any of the profile databases.
     */
    public static boolean isUsernameUnique(String username) {
        ResultSet rsEmployee = getEmployee(username);
        ResultSet rsAdmin = getAdmin(username);
        ResultSet rsPerson = getPerson(username);
        try {
            if (rsEmployee.next() || rsAdmin.next() || rsPerson.next()) {
                return false;
            }
        } catch (Exception e) {
            System.out.println("Error checking username uniqueness");
        }
        return true;
    }

    /**
     * Retrieves details of a room from the hotel rooms database based on the room number.
     *
     * @param roomNumber The room number to retrieve details for.
     * @return A ResultSet containing the room details, null if no details are found.
     */
    public static ResultSet getRoom(int roomNumber) {
        ResultSet resultSet = null;
        try {
            Statement statement = conHot.createStatement();
            resultSet = statement.executeQuery("SELECT * FROM ROOMS WHERE ROOMNUMBER = " + roomNumber);
        } catch (Exception e) {
            System.out.println("Error retrieving room details");
        }
        return resultSet;
    }

    /**
     * Removes a room from the hotel rooms database based on the room number.
     *
     * @param roomNumber The room number to remove.
     */
    public static void removeRoom(Integer roomNumber) {
        try {
            Statement statement = conHot.createStatement();
            statement.execute("DELETE FROM ROOMS WHERE ROOMNUMBER = " + roomNumber);
        } catch (Exception e) {
            System.out.println("Error removing room");
        }
    }

    /**
     * Removes a guest profile from the guest profiles database based on the username.
     *
     * @param username The username of the guest to remove.
     */
    public static void removeGuest(String username) {
        try {
            Statement statement = conGuest.createStatement();
            statement.execute("DELETE FROM PERSONPROFILES WHERE USERNAME = '" + username + "'");
        } catch (Exception e) {
            System.out.println("Error removing guest profile");
        }
    }

    /**
     * Removes an employee profile from the employee profiles database based on the username.
     *
     * @param username The username of the employee to remove.
     */
    public static void removeEmployee(String username) {
        try {
            Statement statement = conEmployee.createStatement();
            statement.execute("DELETE FROM EMPLOYEEPROFILES WHERE USERNAME = '" + username + "'");
        } catch (Exception e) {
            System.out.println("Error removing employee profile");
        }
    }

    /**
     * Removes all reservations from the reservations database.
     */
    public static void removeReservations() {
        try {
            Statement statement = conRes.createStatement();
            statement.execute("TRUNCATE TABLE RESERVATIONS");
        } catch (Exception e) {
            System.out.println("Error clearing all reservations");
        }
    }

    /**
     * Removes all rooms from the hotel rooms database.
     */
    public static void removeRooms() {
        try {
            Statement statement = conHot.createStatement();
            statement.execute("TRUNCATE TABLE ROOMS");
        } catch (Exception e) {
            System.out.println("Error clearing all rooms");
        }
    }

    /**
     * Retrieves all reservations from the reservations database.
     *
     * @return ResultSet containing all reservations, null if there are no reservations.
     */
    public static ResultSet getReservations() {
        ResultSet resultSet = null;
        try {
            Statement statement = conRes.createStatement();
            resultSet = statement.executeQuery("SELECT * FROM RESERVATIONS");
        } catch (Exception e) {
            System.out.println("Error retrieving all reservations");
        }
        return resultSet;
    }

    /**
     * Inserts a new person profile into the person profiles database.
     *
     * @param personDetails String containing comma-separated values for the person's profile (ID, name, email, etc.).
     * @throws SQLException If an error occurs during the insert operation.
     */
    public static void insertIntoPersonProfiles(String personDetails) throws SQLException {
        try {
            Statement statement = conGuest.createStatement();
            String[] details = personDetails.split(",");
            statement.executeUpdate("INSERT INTO PERSONPROFILES (PersonId, FirstName, LastName, Email, PhoneNumber, Username, Password) VALUES ('" +
                    details[0] + "', '" + details[1] + "', '" + details[2] + "', '" + details[3] + "', '" + details[4] + "', '" +
                    details[5] + "', '" + details[6] + "')");
        } catch (SQLException e) {
            throw new RuntimeException("Failed to insert person profile: " + e.getMessage(), e);
        }
    }

    /**
     * Inserts a new employee profile into the employee profiles database.
     *
     * @param employeeDetails String containing comma-separated values for the employee's profile.
     * @throws SQLException If an error occurs during the insert operation.
     */
    public static void insertIntoEmployeeProfiles(String employeeDetails) throws SQLException {
        try {
            Statement statement = conEmployee.createStatement();
            String[] details = employeeDetails.split(",");
            statement.executeUpdate("INSERT INTO EMPLOYEEPROFILES (PersonId, FirstName, LastName, Email, PhoneNumber, Username, Password) VALUES ('" +
                    details[0] + "', '" + details[1] + "', '" + details[2] + "', '" + details[3] + "', '" + details[4] + "', '" +
                    details[5] + "', '" + details[6] + "')");
        } catch (SQLException e) {
            throw new RuntimeException("Failed to insert employee profile: " + e.getMessage(), e);
        }
    }

    /**
     * Inserts a new admin profile into the admin profiles database.
     *
     * @param adminDetails String containing comma-separated values for the admin's profile.
     * @throws SQLException If an error occurs during the insert operation.
     */
    public static void insertIntoAdminProfiles(String adminDetails) throws SQLException {
        try {
            Statement statement = conAdmin.createStatement();
            String[] details = adminDetails.split(",");
            statement.executeUpdate("INSERT INTO ADMINPROFILES (PersonId, FirstName, LastName, Email, PhoneNumber, Username, Password) VALUES ('" +
                    details[0] + "', '" + details[1] + "', '" + details[2] + "', '" + details[3] + "', '" + details[4] + "', '" +
                    details[5] + "', '" + details[6] + "')");
        } catch (SQLException e) {
            throw new RuntimeException("Failed to insert admin profile: " + e.getMessage(), e);
        }
    }

    /**
     * Retrieves reservations based on a username from the reservations database.
     *
     * @param username The username to look up reservations for.
     * @return ResultSet containing the reservations for the specified username, null if none are found.
     */
    public static ResultSet getReservations(String username) {
        ResultSet resultSet = null;
        try {
            Statement statement = conRes.createStatement();
            resultSet = statement.executeQuery("SELECT * FROM RESERVATIONS WHERE USERNAME = '" + username + "'");
        } catch (Exception e) {
            System.out.println("Error retrieving reservations by username");
        }
        return resultSet;
    }

    /**
     * Retrieves an employee profile based on the username from the employee profiles database.
     *
     * @param username The username to retrieve the employee profile for.
     * @return ResultSet containing the employee profile, null if not found.
     */
    public static ResultSet getEmployee(String username) {
        ResultSet resultSet = null;
        try {
            Statement statement = conEmployee.createStatement();
            resultSet = statement.executeQuery("SELECT * FROM EMPLOYEEPROFILES WHERE USERNAME = '" + username + "'");
        } catch (Exception e) {
        }
        return resultSet;
    }

    /**
     * Retrieves an admin profile based on the username from the admin profiles database.
     *
     * @param username The username to retrieve the admin profile for.
     * @return ResultSet containing the admin profile, null if not found.
     */
    public static ResultSet getAdmin(String username) {
        ResultSet resultSet = null;
        try {
            Statement statement = conAdmin.createStatement();
            resultSet = statement.executeQuery("SELECT * FROM ADMINPROFILES WHERE USERNAME = '" + username + "'");
        } catch (Exception e) {
        }
        return resultSet;
    }

    /**
     * Retrieves a person profile based on the username from the person profiles database.
     *
     * @param username The username to retrieve the person profile for.
     * @return ResultSet containing the person profile, null if not found.
     */
    public static ResultSet getPerson(String username) {
        ResultSet resultSet = null;
        try {
            Statement statement = conGuest.createStatement();
            resultSet = statement.executeQuery("SELECT * FROM PERSONPROFILES WHERE USERNAME = '" + username + "'");
        } catch (Exception e) {
        }
        return resultSet;
    }

    /**
     * Updates the password for a user across all profile databases (guest, employee, admin).
     *
     * @param username The username whose password is to be updated.
     * @param newPassword The new password to set.
     * @throws Exception If the update operation fails.
     */
    public static void updatePassword(String username, String newPassword) throws Exception {
        ResultSet rsEmployee = getEmployee(username);
        ResultSet rsAdmin = getAdmin(username);
        ResultSet rsPerson = getPerson(username);

        try {
            String query;
            PreparedStatement preparedStatement;
            if (rsEmployee.next()) {
                query = "UPDATE EMPLOYEEPROFILES SET PASSWORD = ? WHERE USERNAME = ?";
                preparedStatement = conEmployee.prepareStatement(query);
                preparedStatement.setString(1, newPassword);
                preparedStatement.setString(2, username);
                preparedStatement.executeUpdate();
            }

            if (rsAdmin.next()) {
                query = "UPDATE ADMINPROFILES SET PASSWORD = ? WHERE USERNAME = ?";
                preparedStatement = conAdmin.prepareStatement(query);
                preparedStatement.setString(1, newPassword);
                preparedStatement.setString(2, username);
                preparedStatement.executeUpdate();
            }

            if (rsPerson.next()) {
                query = "UPDATE PERSONPROFILES SET PASSWORD = ? WHERE USERNAME = ?";
                preparedStatement = conGuest.prepareStatement(query);
                preparedStatement.setString(1, newPassword);
                preparedStatement.setString(2, username);
                preparedStatement.executeUpdate();
                query = "UPDATE CASHIERINGDATA SET PASSWORD = ? WHERE USERNAME = ?";
                preparedStatement = conCash.prepareStatement(query);
                preparedStatement.setString(1, newPassword);
                preparedStatement.setString(2, username);
                preparedStatement.executeUpdate();
            }
        } catch (Exception e) {
            throw new Exception("Failed to update password", e);
        }
    }

    /**
     * Inserts new hotel room data into the hotel rooms database.
     *
     * @param roomDetails A string containing the details of the room to be inserted.
     * @throws SQLException If an SQL error occurs during the insert operation.
     */
    public static void insertIntoHotelRoomsData(String roomDetails) throws SQLException {
        try {
            Statement statement = conHot.createStatement();
            String[] details = roomDetails.split(",");
            int roomNumber = Integer.parseInt(details[0]);
            boolean smokingAllowed = details[5].equalsIgnoreCase("true");
            String query = "INSERT INTO ROOMS (ROOMNUMBER, ROOMSTATUS, ROOMTYPE, BEDTYPE, QUALITYLEVEL, SMOKINGALLOWED) VALUES (" +
                    roomNumber + ", '" + details[1] + "', '" + details[2] + "', '" + BedType.databaseFormat(details[3]) + "', '" +
                    QualityLevel.databaseFormat(details[4]) + "', " + smokingAllowed + ")";
            statement.executeUpdate(query);
        } catch (SQLException e) {
            throw new RuntimeException("Failed to insert hotel room data: " + e.getMessage(), e);
        }
    }

    /**
     * Retrieves the entire catalogue from the catalogue database.
     *
     * @return ResultSet containing all catalogue items, throws SQLException if retrieval fails.
     * @throws SQLException If an SQL error occurs during data retrieval.
     */
    public static ResultSet getCatalogue() throws SQLException {
        ResultSet resultSet = null;
        try {
            Statement statement = conCatalogue.createStatement();
            resultSet = statement.executeQuery("SELECT * FROM CATALOGUE");
            return resultSet;
        } catch (SQLException e) {
            throw new RuntimeException("Failed to retrieve catalogue: " + e.getMessage(), e);
        }
    }

    /**
     * Inserts a new reservation into the reservations database.
     *
     * @param reservationDetails A string containing the details of the reservation to be inserted.
     * @throws SQLException If an SQL error occurs during the insert operation.
     */
    public static void insertIntoReservations(String reservationDetails) throws SQLException {
        try {
            Statement statement = conRes.createStatement();
            String[] details = reservationDetails.split(",");
            String query = "INSERT INTO Reservations (RoomNumber, Username, StartDate, EndDate) VALUES ('" +
                    details[0] + "', '" + details[1] + "', '" + details[2] + "', '" + details[3] + "')";
            statement.executeUpdate(query);
        } catch (SQLException e) {
            throw new RuntimeException("Failed to insert reservation: " + e.getMessage(), e);
        }
    }

    /**
     * Retrieves a specific card's details from the cashiering data based on the username.
     *
     * @param username The username associated with the card.
     * @return ResultSet containing the card details, null if not found.
     */
    public static ResultSet getCard(String username) {
        ResultSet resultSet = null;
        try {
            Statement statement = conCash.createStatement();
            resultSet = statement.executeQuery("SELECT * FROM CASHIERINGDATA WHERE USERNAME = '" + username + "'");
            return resultSet;
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Checks if a given card number and expiration date match the records in the cashiering database.
     *
     * @param username The username associated with the card.
     * @param cardNumber The card number to match.
     * @param expirationDate The expiration date to match.
     * @return true if the card number and expiration date match the records, false otherwise.
     */
    public static boolean cardNumMatchExp(String username, String cardNumber, String expirationDate) {
        try {
            ResultSet resultSet = getCard(username);
            if (!resultSet.next()) {
                return false;
            } else {
                String storedCardNumber = resultSet.getString("CARDNUMBER");
                String storedExpirationDate = resultSet.getString("EXPIRATIONDATE");
                return cardNumber.equals(storedCardNumber) && expirationDate.equals(storedExpirationDate);
            }
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Inserts or updates a card's details in the cashiering database based on the provided username.
     *
     * @param cardDetails A string containing the card details to be inserted or updated.
     * @throws SQLException If an SQL error occurs during the insert or update operation.
     */
    public static void insertIntoCards(String cardDetails) throws SQLException {
        try {
            Statement statement = conCash.createStatement();
            String[] details = cardDetails.split(",");
            ResultSet resultSet = statement.executeQuery("SELECT * FROM CASHIERINGDATA WHERE USERNAME = '" + details[0] + "'");
            if (resultSet.next()) {
                String query = "UPDATE CASHIERINGDATA SET CARDNUMBER = ?, EXPIRATIONDATE = ? WHERE USERNAME = ?";
                PreparedStatement preparedStatement = conCash.prepareStatement(query);
                preparedStatement.setString(1, details[2]);
                preparedStatement.setString(2, details[3]);
                preparedStatement.setString(3, details[0]);
                preparedStatement.executeUpdate();
            } else {
                statement.executeUpdate("INSERT INTO CASHIERINGDATA (USERNAME, PASSWORD, CARDNUMBER, EXPIRATIONDATE, RUNNINGBALANCE) VALUES ('" +
                        details[0] + "', '" + details[1] + "', '" + details[2] + "', '" + details[3] + "', " + Integer.parseInt(details[4]) + ")");
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to insert or update card details: " + e.getMessage(), e);
        }
    }

    /**
     * Retrieves all rooms from the hotel rooms database.
     *
     * @return ResultSet containing all room records.
     */
    public static ResultSet getRooms() {
        ResultSet resultSet = null;
        try {
            Connection connection = conHot;
            Statement statement = connection.createStatement();
            resultSet = statement.executeQuery("SELECT * FROM ROOMS");
        } catch (Exception e) {
            System.out.println("Error retrieving all rooms");
        }
        return resultSet;
    }

    /**
     * Updates the status of a specific room in the hotel rooms database.
     *
     * @param roomNumber The room number whose status needs updating.
     * @param newStatus The new status to set for the room.
     * @throws SQLException If an SQL error occurs during the update operation.
     */
    public static void updateRoom(int roomNumber, RoomStatus newStatus) throws SQLException {
        try {
            String query = "UPDATE ROOMS SET ROOMSTATUS = ? WHERE ROOMNUMBER = ?";
            PreparedStatement preparedStatement = conHot.prepareStatement(query);
            preparedStatement.setString(1, newStatus.toString());
            preparedStatement.setInt(2, roomNumber);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Failed to update room status: " + e.getMessage(), e);
        }
    }
}