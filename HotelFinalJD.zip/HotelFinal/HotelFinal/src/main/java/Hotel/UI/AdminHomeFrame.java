package Hotel.UI;

import Hotel.Central.CentralDatabase;
import Hotel.Central.CentralReservations;
import Hotel.Central.CentralRoom;
import Hotel.Enums.RoomStatus;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.logging.Level;

public class AdminHomeFrame extends JFrame {
    public CardLayout cl;
    public JPanel container, homePanel;
    private JLabel welcomeLabel;
    private GridBagConstraints gbc;
    private JButton processCheckBtn, roomStatusBtn, reservationStatusBtn,
            billingBtn, LogoutBtn, createAccountBtn, resetAccountPasswordBtn,
            initBtn, AuditBtn;
    private static AdminHomeFrame adminFrame;
    private JFrame checkInFrame;

    public AdminHomeFrame(String username, String password) throws IllegalArgumentException {
        adminFrame = this;
        setTitle("Hotel Transylvania");
        setSize(new Dimension(1080 , 480));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Center the frame on the screen

        // Panel that holds all potential panels
        cl = new CardLayout();
        container = new JPanel(cl);

        // Home page, can Reserve / Edit / Logout
        homePanel = new JPanel(new GridBagLayout());

        // "Welcome, [username]"
        welcomeLabel = new JLabel("Welcome, " + username);
        welcomeLabel.setFont(new Font("Helvetica", Font.PLAIN, 40));
        welcomeLabel.setHorizontalAlignment(SwingConstants.CENTER);

        // Process a guest check in or check out
        processCheckBtn = new JButton("Check In/Out");
        processCheckBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                //CentralDatabase.updateRoom(myReservation.getRoomID(), RoomStatus.OcDi);
                checkInFrame = new CheckInFrame(username, password);
                checkInFrame.setVisible(true);

            }
        });

        //TODO: Add edit functionality
        // Opens new frame that displays room status
        roomStatusBtn = new JButton("Rooms Status");
        roomStatusBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JFrame tableFrame = new JFrame();
                JPanel tablePanel= new JPanel();

                String[] columnNames = {"Rm #", "Rm Stat", "Rm Typ", "RBed Typ", "Qual lvl", "Smokng"};
                DefaultTableModel roomAvailModel = new DefaultTableModel();
                for(String name : columnNames) {
                    roomAvailModel.addColumn(name);
                }

                JTable availRooms = new JTable(roomAvailModel);
                ResultSet rooms = CentralDatabase.getRooms();
                try {
                    while (rooms.next()) {
                        Object[] obj = new Object[6];
                        try {
                            obj[0] = rooms.getInt("ROOMNUMBER");
                            obj[1] = rooms.getString("ROOMSTATUS");
                            obj[2] = rooms.getString("ROOMTYPE");
                            obj[3] = rooms.getString("BEDTYPE");
                            obj[4] = rooms.getString("QUALITYLEVEL");
                            obj[5] = rooms.getBoolean("SMOKINGALLOWED");
                            roomAvailModel.insertRow(0, obj);
                        } catch (Exception excA) {}
                    }
                }catch (Exception roomError) {}
                tableFrame.getContentPane().add(new JScrollPane(availRooms));
                availRooms.setFillsViewportHeight(true);

                tablePanel.setLayout(new BorderLayout());
                tableFrame.setSize(500,500);
                tableFrame.setVisible(true);
            }
        });

        //TODO: Add edit functionality
        // Opens new frame that displays reservations
        reservationStatusBtn = new JButton("Reservations");
        reservationStatusBtn.addActionListener(new ActionListener() {
            // Load reserve room panel into frame
            public void actionPerformed(ActionEvent e) {
                JFrame tableFrame = new JFrame();
                JPanel tablePanel= new JPanel();

                String[] columnNames = {"Rm #", "Guest", "Start Date", "End Date"};
                DefaultTableModel reservationModel = new DefaultTableModel();
                for(String name : columnNames) {
                    reservationModel.addColumn(name);
                }

                try {
                    ResultSet res = CentralDatabase.getReservations();

                    while(res.next()) {
                        Object[] obj = new Object[4];

                        obj[0]= res.getInt("ROOMNUMBER");
                        obj[1]= res.getString("USERNAME");
                        obj[2]= res.getString("STARTDATE");
                        obj[3]= res.getString("ENDDATE");

                        reservationModel.insertRow(0, obj);
                    }
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                JTable availRooms = new JTable(reservationModel);
                tableFrame.getContentPane().add(new JScrollPane(availRooms));
                availRooms.setFillsViewportHeight(true);

                tablePanel.setLayout(new BorderLayout());
                tableFrame.setSize(500,500);
                tableFrame.setVisible(true);
            }
        });

        //TODO: Connect with billing system
        // Calculates billing information for a guest
        billingBtn = new JButton("Get Billing Information");
        billingBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String guestUsername = JOptionPane.showInputDialog("Enter the guest's username");
                double cost = 0.0;

                ResultSet res = CentralDatabase.getReservations(guestUsername);
                try {
                    while(res.next()) {
                        cost += res.getInt("COST");
                    }
                    JOptionPane.showMessageDialog(container, guestUsername + ": $" + cost, "Balance", JOptionPane.PLAIN_MESSAGE);
                } catch (Exception eCost) {
                    JOptionPane.showMessageDialog(container, "No account matching that username could be found");
                }
            }
        });

        // Creates a new employee account, with a default password of "password"
        createAccountBtn = new JButton("Add Employee");
        createAccountBtn.addActionListener(new ActionListener() {
            // Load reserve room panel into frame
            public void actionPerformed(ActionEvent e) {
                JFrame registrationFrame = new EmployeeRegistrationFrame();
                registrationFrame.setVisible(true);
            }
        });

        //TODO: Reset password in database, not just in Arlow
        // Resets the password of a given guest to the default "password"
        resetAccountPasswordBtn = new JButton("Reset User Password");
        resetAccountPasswordBtn.addActionListener(new ActionListener() {
            // Load reserve room panel into frame
            public void actionPerformed(ActionEvent e) {
                String accountUsername = JOptionPane.showInputDialog("Enter the username whose password you would like to reset");

                try {
                    if (JOptionPane.showConfirmDialog(container, "Are you sure you want to reset " + accountUsername + "'s password?", "Confirm Password Reset", JOptionPane.YES_NO_OPTION) == 0) {
                        String guestPassword = JOptionPane.showInputDialog("Enter the new password");
                        CentralDatabase.updatePassword(accountUsername, guestPassword);
                        JOptionPane.showMessageDialog(container, "Password reset");
                    }  else {
                        JOptionPane.showMessageDialog(container, "Password was not reset");
                    }
                } catch (Exception e1) {
                    System.out.println("Unable to reset account password");
                    e1.printStackTrace();
                }
            }
        });

        initBtn = new JButton("Initialize Hotel");
        initBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int choice = JOptionPane.showConfirmDialog(null, "Are you sure you want to initialize the hotel? " +
                        "This will wipe all current room and reservation data");

                if(choice == JOptionPane.YES_OPTION) {
                    CentralDatabase.removeRooms();
                    CentralDatabase.removeReservations();

                    if(!CentralRoom.initializeRooms(3, 36, username)) {
                        JOptionPane.showMessageDialog(container, "Cannot initialize rooms");
                    } else {
                        JOptionPane.showMessageDialog(container, "Room initialization successful!");
                    }
                }
            }
        });

        // Closes GuestHomeFrame and opens new LoginFrame
        LogoutBtn = new JButton("Logout");
        LogoutBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Logic to save user information / updates, controller?
                new LoginFrame();
                dispose();
            }
        });

        AuditBtn = new JButton("Audit");
        AuditBtn.addActionListener(new ActionListener() {
            @Override
           public void actionPerformed(ActionEvent e) {
               //if(!CentralCashiering.run()) {
                if(!CentralReservations.updateReservations()) {
                   //MyLogger.logger.log(Level.SEVERE, "Cannot update Central Reservations. Exiting program...");
                   System.exit(1);
               } else {
                   JOptionPane.showMessageDialog(container, "Success!");
               }
           }
       });

        // Layout of HomePanel
        gbc = new GridBagConstraints();
        gbc.insets = new Insets(3, 3, 3, 3);
        gbc.gridx = gbc.gridy = 0;
        homePanel.add(welcomeLabel, gbc);

        // Layout of JButtons
        gbc.gridheight = GridBagConstraints.CENTER;
        JPanel buttons = new JPanel();
        buttons.setLayout(new GridLayout(5, 5, 10, 10));

        buttons.add(processCheckBtn);
        buttons.add(roomStatusBtn);
        buttons.add(reservationStatusBtn);
        buttons.add(billingBtn);
        buttons.add(createAccountBtn);
        buttons.add(resetAccountPasswordBtn);
        buttons.add(initBtn);
        buttons.add(AuditBtn);
        buttons.add(LogoutBtn);

        // Reusing GridBagConstraints for layout of homePanel
        gbc.gridx = 0;
        gbc.gridy = 1;
        homePanel.add(buttons, gbc);

        container.add(homePanel, "Home");
        add(container);
        cl.show(container, "Home");
        setVisible(true);
    }
}






