package Hotel.ShoppingService;

import static Hotel.Utilities.Utilities.primes;
import static java.lang.Math.abs;

/**
 * Represents an item in the shopping catalogue, including its name and detailed specifications.
 */
public class Item {
    // Data members
    private String name;
    private ItemSpec specification;

    /**
     * Gets the name of the item.
     *
     * @return The name of the item.
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the name of the item.
     *
     * @param n The new name of the item.
     */
    public void setName(String n) {
        name = n;
    }

    /**
     * Gets the specification of the item.
     *
     * @return The specification object associated with this item.
     */
    public ItemSpec getSpecification() {
        return specification;
    }

    /**
     * Sets the specification of the item.
     *
     * @param s The new specification to be set.
     */
    public void setSpecification(ItemSpec s) {
        specification = s;
    }

    /**
     * Generates a hash code for this item based on its name and specification.
     *
     * @return The hash code for this item.
     */
    public int hashCode() {
        int result = 1;
        result = primes[3] * result + (name != null ? name.hashCode() : 0);
        result = primes[4] * result + (specification != null ? specification.hashCode() : 0);
        return abs(result);
    }
}