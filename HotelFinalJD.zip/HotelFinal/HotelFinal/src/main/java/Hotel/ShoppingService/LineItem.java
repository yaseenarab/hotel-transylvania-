package Hotel.ShoppingService;

import java.math.BigDecimal;

/**
 * Abstract class representing a line item in a shopping cart or billing information.
 * Acts as a parent for finalized cart purchases and reservations.
 */
public abstract class LineItem {
    protected Long id;
    protected BigDecimal price;
    protected String name;
    protected String description;
    protected Integer quantity;

    /**
     * Generates a formatted line item string.
     *
     * @return The formatted line item string.
     */
    public String generateLineItem() {
        return id + ","
                + price + ","
                + name + ","
                + description + ","
                + quantity;
    }

    // Other methods and properties specific to LineItem can be added here
}