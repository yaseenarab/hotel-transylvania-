package Hotel.ShoppingService;

import java.util.Arrays;
import java.util.Date;

import static Hotel.Utilities.Utilities.primes;
import static java.lang.Math.abs;

/**
 * Represents a sale transaction in the hotel's shopping service.
 * Each sale has a date, ID, and a list of line items.
 */
public class Sale {
    private Date date; // Also stores time of sale
    private Long ID;
    private SaleLineItem[] lineItemList;

    /**
     * Calculates the hash code value for this Sale object.
     * Overrides the hashCode() method from the Object class.
     *
     * @return The hash code value for this Sale object.
     */
    @Override
    public int hashCode() {
        int result = 1;

        result = primes[0] * result + date.hashCode();
        result = primes[1] * result + ID.hashCode();
        result = primes[2] * result + Arrays.hashCode(lineItemList);

        return abs(result);
    }

    /**
     * Generates a new SaleLineItem instance.
     *
     * @return A new SaleLineItem instance.
     */
    public SaleLineItem generateSLI() {
        return new SaleLineItem();
    }
}
