package Hotel.ShoppingService;

import Hotel.Central.CentralDatabase;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;

/**
 * Data Transfer Object (DTO) class responsible for initializing and populating
 * the shopping catalogue from the database into a specified HashMap.
 */
public class CatalogueDTO {

    /**
     * Initializes the catalogue by loading item specifications from the database
     * and populating them into the provided HashMap.
     *
     * @param c The HashMap that will store item specifications keyed by item IDs.
     *          If null, a new HashMap is created.
     */
    public static void initCatalogue(HashMap<Long, ItemSpec> c) {
        if (c == null) {
            c = new HashMap<>();
        }
        try {
            ResultSet rs = CentralDatabase.getCatalogue();
            while (rs.next()) {
                ItemSpec is = new ItemSpec(
                        rs.getString("itemName"),
                        rs.getString("itemDescription"),
                        rs.getBigDecimal("itemPrice"),
                        rs.getLong("itemId"),
                        rs.getString("itemImageURL"),
                        rs.getLong("itemQuantity")
                );
                c.put(is.getItemID(), is);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to initialize the catalogue due to a SQL error.", e);
        }
    }
}