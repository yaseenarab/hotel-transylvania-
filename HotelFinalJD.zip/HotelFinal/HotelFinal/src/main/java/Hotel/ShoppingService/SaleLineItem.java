package Hotel.ShoppingService;

import java.math.BigDecimal;

/**
 * Represents a line item in a sale, extending the LineItem class.
 * SaleLineItem objects are used to finalize cart purchases and reservations.
 */
public class SaleLineItem extends LineItem {

    /**
     * Generates a formatted line item string based on the provided parameters.
     *
     * @param id          The ID of the item.
     * @param price       The price of the item.
     * @param name        The name of the item.
     * @param description The description of the item.
     * @param quantity    The quantity of the item.
     * @return A formatted line item string.
     */
    public String generateLineItem(Long id, BigDecimal price, String name, String description, Integer quantity) {
        return super.generateLineItem(id, price, name, description, quantity);
    }
}