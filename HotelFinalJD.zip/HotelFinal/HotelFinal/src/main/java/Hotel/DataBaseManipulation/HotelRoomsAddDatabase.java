package Hotel.DataBaseManipulation;

import java.io.File;
import java.io.FileNotFoundException;
import java.sql.*;

/**
 * Provides functionality for manipulating and managing the hotel rooms database.
 * This includes creating tables, inserting data, and updating records.
 */
public class HotelRoomsAddDatabase {

    private static final String DB_URL = "jdbc:derby:ReservationsData;";

    /**
     * Main method to run database operations.
     *
     * @param args Command line arguments (not used).
     * @throws SQLException if a database access error occurs.
     */
    public static void main(String[] args) throws SQLException {
        HotelRoomsAddDatabase hotelRooms = new HotelRoomsAddDatabase();

        hotelRooms.createTable();
        // Additional methods can be called here to perform more database operations.
    }

    /**
     * Updates specific entries in the database.
     * For example, removing a reservation entry by reservation ID.
     *
     * @throws SQLException if a database access error occurs or this method is called on a closed connection.
     */
    public void updateSpot() throws SQLException {
        try (Connection con = DriverManager.getConnection(DB_URL);
             PreparedStatement pstmt = con.prepareStatement("Delete from Reservations where Reservationid = 'testID'")) {

            pstmt.executeUpdate();
        }
    }

    /**
     * Inserts new data into the database from a CSV file.
     * This method reads a CSV file and inserts data into the 'Catalogue' table.
     *
     * @throws SQLException if a database access error occurs or this method is called on a closed connection.
     */
    public void insertIntoDataBase() throws SQLException {
        try (Connection con = DriverManager.getConnection(DB_URL);
             Statement stmt = con.createStatement();
             Scanner scanner = new Scanner(new File("cat.csv"))) {

            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] split = line.split(",");
                if (split.length == 4) {
                    stmt.executeUpdate("insert into Catalogue(itemid, itemname, cost, quantity) values(" +
                            Integer.parseInt(split[0]) + ",'" + split[1] + "'," + Double.parseDouble(split[2]) + "," +
                            Integer.parseInt(split[3]) + ")");
                }
            }
        } catch (FileNotFoundException e) {
            throw new RuntimeException("File not found", e);
        }
    }

    /**
     * Creates a new table in the database.
     * This method specifically creates a 'CashieringData' table in a database intended for cashiering operations.
     *
     * @throws SQLException if a database access error occurs or this method is called on a closed connection.
     */
    public void createTable() throws SQLException {
        final String CreateDB_URL = "jdbc:derby:CashieringData;create=true";
        try (Connection con = DriverManager.getConnection(CreateDB_URL);
             Statement stmt = con.createStatement()) {

            stmt.execute("CREATE TABLE CashieringData (" +
                    "Username VARCHAR(25)," +
                    "Password VARCHAR(25)," +
                    "CardNumber VARCHAR(25)," +
                    "ExpirationDate VARCHAR(25)," +
                    "RunningBalance Integer)");

            System.out.println("CashieringData table created successfully.");
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Failed to create table: " + e.getMessage());
        }
    }
}