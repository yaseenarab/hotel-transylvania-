package Hotel.Room;

import Hotel.Enums.BedType;
import Hotel.Enums.RoomStatus;

/**
 * Abstract base class for different types of rooms within the hotel.
 * It provides common attributes and operations for all room variants.
 */
public abstract class Room {
    protected RoomStatus roomStatus;
    protected BedType bedType;
    protected Integer numBeds;
    protected Boolean smokingStatus;
    protected Integer roomNumber;

    /**
     * Constructs a Room with default settings.
     */
    Room() {}

    /**
     * Sets the status of the room.
     *
     * @param roomStatus The new status of the room.
     * @throws Exception If the provided roomStatus is null.
     */
    public void setRoomStatus(RoomStatus roomStatus) throws Exception {
        if(roomStatus == null) {
            throw new Exception("Fatal error: Room status value is NULL");
        }
        this.roomStatus = roomStatus;
    }

    /**
     * Sets the type of bed in the room.
     *
     * @param bedType The new bed type of the room.
     * @throws Exception If the provided bedType is null.
     */
    public void setBedType(BedType bedType) throws Exception {
        if(bedType == null) {
            throw new Exception("Fatal error: Bed type value is NULL");
        }
        this.bedType = bedType;
    }

    /**
     * Sets the number of beds in the room.
     *
     * @param numBeds The new number of beds in the room.
     * @throws Exception If the provided numBeds is null.
     */
    public void setNumBeds(Integer numBeds) throws Exception {
        if(numBeds == null) {
            throw new Exception("Fatal error: Number of beds value is NULL");
        }
        this.numBeds = numBeds;
    }

    /**
     * Sets the smoking status of the room.
     *
     * @param smokingStatus The new smoking status of the room.
     * @throws Exception If the provided smokingStatus is null.
     */
    public void setSmokingStatus(Boolean smokingStatus) throws Exception {
        if(smokingStatus == null) {
            throw new Exception("Fatal error: Smoking status value is NULL");
        }
        this.smokingStatus = smokingStatus;
    }

    /**
     * Sets the room number.
     *
     * @param roomNumber The new room number.
     * @throws Exception If the provided roomNumber is null.
     */
    public void setRoomNumber(Integer roomNumber) throws Exception {
        if(roomNumber == null) {
            throw new Exception("Fatal error: Room number value is NULL");
        }
        this.roomNumber = roomNumber;
    }

    // Accessor methods

    /**
     * Gets the bed type of the room.
     * @return The bed type of the room.
     */
    public BedType getBedType() {
        return this.bedType;
    }

    /**
     * Gets the current status of the room.
     * @return The current room status.
     */
    public RoomStatus getRoomStatus() {
        return this.roomStatus;
    }

    /**
     * Gets the smoking status of the room.
     * @return The smoking status.
     */
    public Boolean getSmokingStatus() {
        return this.smokingStatus;
    }

    /**
     * Gets the room number.
     * @return The room number.
     */
    public Integer getRoomNumber() {
        return this.roomNumber;
    }

    /**
     * Provides a string representation of the room's attributes.
     * @return A string detailing the room number, status, bed type, and smoking status.
     */
    @Override
    public String toString() {
        return this.roomNumber + ", " + this.roomStatus + ", " + this.bedType + ", " + this.smokingStatus;
    }
}