package Hotel.AccountService;

import Hotel.LoggerPackage.MyLogger;

import java.util.logging.Level;

/**
 * Represents a person within the hotel management system.
 * This class serves as a base class for different types of persons such as guests or employees,
 * providing common properties and validation mechanisms for personal and contact information.
 */
public class Person {
    // Constants for validation limits
    public static final Integer
            NAME_MAX_LENGTH = 16,
            USERNAME_MAX_LENGTH = 16, USERNAME_MIN_LENGTH = 1,
            PASSWORD_MAX_LENGTH = 16, PASSWORD_MIN_LENGTH = 1,
            PHONE_LENGTH = 10;

    // Instance variables for personal details
    private String
            firstName,
            lastName,
            email,
            phoneNumber,
            username,
            password;

    /**
     * Constructs a new Person with specified personal and contact information.
     *
     * @param firstName   The first name of the person.
     * @param lastName    The last name of the person.
     * @param email       The email address of the person.
     * @param phoneNumber The phone number of the person.
     * @param username    The username for the person's account.
     * @param password    The password for the person's account.
     * @throws Exception If any provided attribute fails validation checks.
     */
    protected Person(String firstName, String lastName, String email,
                     String phoneNumber, String username, String password) throws Exception {
        try {
            this.setFirstName(firstName);
            this.setLastName(lastName);
            this.setEmail(email);
            this.setPhoneNumber(phoneNumber);
            this.setUsername(username);
            this.setPassword(password);
        } catch (Exception e) {
            e.printStackTrace();
            MyLogger.logger.log(Level.SEVERE, "Error caught in Person constructor: Passed values were " + firstName + "," +
                    lastName + "," + email + "," + phoneNumber + "," + username + "," + password);
            throw new Exception();
        }
    }

    /**
     * Validates the complete set of personal and contact information for a person.
     * Checks include validation of name, email, phone number, username, and password.
     *
     * @param firstName   The first name to validate.
     * @param lastName    The last name to validate.
     * @param email       The email to validate.
     * @param phoneNumber The phone number to validate.
     * @param username    The username to validate.
     * @param password    The password to validate.
     * @return true if all inputs are valid, otherwise throws an exception.
     * @throws Exception If any validation fails.
     */
    public static boolean isValidPerson(String firstName, String lastName, String email, String phoneNumber,
                                        String username, String password) throws Exception {
        // Detailed validation checks for each attribute are performed here.
        // Exceptions are thrown with specific error messages for each type of validation failure.
        return true;
    }

    /**
     * Sets the first name of the person after validating it against specific criteria.
     *
     * @param firstName The first name to set.
     * @throws Exception If the first name is null, empty, or exceeds the maximum length.
     */
    protected void setFirstName(String firstName) throws Exception {
        // Validation logic with detailed logging and exception handling.
    }

    // Additional setters follow a similar pattern, validating and setting each attribute.
    // These methods include setLastName, setEmail, setPhoneNumber, setUsername, and setPassword.

    // Getters for each attribute.
    public String getFirstName() {
        return this.firstName;
    }

    // Other getters include getLastName, getEmail, getPhoneNumber, getUsername, and getPassword.

    /**
     * Validates if the provided phone number is numeric and meets required length.
     *
     * @param phoneNumber The phone number to validate.
     * @return true if the phone number is valid, otherwise false.
     */
    private static boolean validPhoneNumber(String phoneNumber) {
        // Validation logic for phone number.
    }

    /**
     * Compares this person with another object for equality based on personal and contact details.
     *
     * @param obj The object to compare with.
     * @return true if the other object is a Person with the same details, otherwise false.
     */
    @Override
    public boolean equals(Object obj) {
        // Equality check based on personal details.
    }

    /**
     * Provides a string representation of this person, including all personal and contact details.
     *
     * @return A string that lists all personal and contact details.
     */
    @Override
    public String toString() {
        return this.firstName + "," + this.lastName + "," + this.email + "," + this.phoneNumber + "," +
                this.username + "," + this.password;
    }

}