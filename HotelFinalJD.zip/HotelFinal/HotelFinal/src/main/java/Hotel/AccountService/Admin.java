package Hotel.AccountService;

/**
 * Represents an administrative user with extended privileges in the hotel management system.
 * This class extends the {@link Employee} class, inheriting its basic user properties and adding
 * administrative-specific functionalities.
 */
public class Admin extends Employee {

    /**
     * Constructs a new Admin with specified details.
     * This constructor initializes a new Admin with attributes such as employee ID, first name,
     * last name, email, phone number, username, and password by calling the superclass constructor.
     *
     * @param employeeID   The unique identifier for this admin.
     * @param firstName    The first name of the admin.
     * @param lastName     The last name of the admin.
     * @param email        The email address of the admin.
     * @param phoneNumber  The phone number of the admin.
     * @param username     The username for the admin's account.
     * @param password     The password for the admin's account.
     * @throws Exception   If an error occurs during the creation process, such as validation failure.
     */
    public Admin(String employeeID, String firstName, String lastName, String email,
                 String phoneNumber, String username, String password) throws Exception {
        super(employeeID, firstName, lastName, email, phoneNumber, username, password);
    }

    /**
     * Sets a new, unique employee ID for this admin by generating it using a predefined method.
     * This method assumes the existence of a static method in class Arlow that generates a unique
     * admin ID.
     *
     * @throws Exception  If an error occurs during ID generation, e.g., if the generated ID is not unique.
     */
    public void setEmployeeID() throws Exception {
        employeeID = Arlow.generateAdminId(100000000);
    }
}