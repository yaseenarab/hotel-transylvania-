package Hotel.RoomService;

import Hotel.RoomService.Enums.BedType;
import Hotel.RoomService.Enums.RoomStatus;

/**
 * Represents a hotel room with properties defining its status, type, smoking policy, and identification.
 */
public class Room {
    // Room properties
    protected RoomStatus roomStatus;
    protected BedType bedType;
    protected Boolean smokingStatus;
    protected Integer roomNumber;

    /**
     * Constructs a Room object with specified attributes.
     *
     * @param roomStatus     the status of the room (e.g., Vacant, Occupied)
     * @param bedType        the type of bed in the room (e.g., King, Queen)
     * @param smokingStatus  whether smoking is allowed in the room
     * @param roomNumber     the room number identifier
     * @throws Exception if an initialization error occurs
     */
    public Room(RoomStatus roomStatus, BedType bedType, Boolean smokingStatus, Integer roomNumber) throws Exception {
        try {
            this.setRoomStatus(roomStatus);
            this.setBedType(bedType);
            this.setSmokingStatus(smokingStatus);
            this.setRoomNumber(roomNumber);
            System.out.println("Successfully initialized Room");
        } catch(Exception e) {
            throw new Exception("Exception caught in Room constructor.", e);
        }
    }

    /**
     * Sets the bed type of this room.
     *
     * @param bedType the type of bed
     * @throws Exception if bedType is null or setting fails
     */
    public void setBedType(BedType bedType) throws Exception {
        if (bedType == null) {
            throw new Exception("Fatal error thrown in setBedType, value is NULL");
        }
        this.bedType = bedType;
    }

    /**
     * Sets the room status.
     *
     * @param roomStatus the new status of the room
     * @throws Exception if roomStatus is null or setting fails
     */
    public void setRoomStatus(RoomStatus roomStatus) throws Exception {
        if (roomStatus == null) {
            throw new Exception("Fatal error thrown in setRoomStatus, value is NULL");
        }
        this.roomStatus = roomStatus;
    }

    /**
     * Sets the smoking status for this room.
     *
     * @param smokingStatus true if smoking is allowed, false otherwise
     * @throws Exception if smokingStatus is null or setting fails
     */
    public void setSmokingStatus(Boolean smokingStatus) throws Exception {
        if (smokingStatus == null) {
            throw new Exception("Fatal error thrown in setSmokingStatus, value is NULL");
        }
        this.smokingStatus = smokingStatus;
    }

    /**
     * Sets the room number.
     *
     * @param roomNumber the room number identifier
     * @throws Exception if roomNumber is null or setting fails
     */
    public void setRoomNumber(Integer roomNumber) throws Exception {
        if (roomNumber == null) {
            throw new Exception("Fatal error thrown in setRoomNumber, value is NULL");
        }
        this.roomNumber = roomNumber;
    }

    /**
     * Returns the bed type of this room.
     *
     * @return the bed type
     */
    public BedType getBedType() {
        return this.bedType;
    }

    /**
     * Returns the status of this room.
     *
     * @return the room status
     */
    public RoomStatus getRoomStatus() {
        return this.roomStatus;
    }

    /**
     * Returns the smoking status of this room.
     *
     * @return true if smoking is allowed, false otherwise
     */
    public Boolean getSmokingStatus() {
        return this.smokingStatus;
    }

    /**
     * Returns the room number.
     *
     * @return the room number
     */
    public Integer getRoomNumber() {
        return this.roomNumber;
    }

    /**
     * Provides a string representation of the room details.
     *
     * @return a string describing the room
     */
    @Override
    public String toString() {
        return this.roomNumber + ", " + this.roomStatus + ", " + this.bedType + ", " + this.smokingStatus;
    }
}
