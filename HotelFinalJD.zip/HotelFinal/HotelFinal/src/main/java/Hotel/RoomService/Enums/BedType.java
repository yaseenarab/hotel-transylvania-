package Hotel.RoomService.Enums;

/**
 * Enum representing the type of bed in a hotel room.
 */
public enum BedType {
    // Twin, Full, Queen, King
    TW, FL,
    QN, KG;
    private static final BedType[] types = values();

    /**
     * Cycles to the next bed type in the enum sequence.
     * @return the next BedType in the sequence.
     */
    public BedType next() {
        return types[(this.ordinal() + 1) % types.length];
    }

    /**
     * Converts a string to its corresponding BedType enum.
     * @param str the string to convert.
     * @return the corresponding BedType.
     * @throws IllegalArgumentException if the string does not match any BedType.
     */
    public static BedType getEnum(String str) {
        str = str.toLowerCase();
        if (str.contains("tw")) {
            return BedType.TW;
        } else if (str.contains("fu")) {
            return BedType.FL;
        } else if (str.contains("qu")) {
            return BedType.QN;
        } else if (str.contains("ki")) {
            return BedType.KG;
        } else {
            throw new IllegalArgumentException("Invalid BedType");
        }
    }
}