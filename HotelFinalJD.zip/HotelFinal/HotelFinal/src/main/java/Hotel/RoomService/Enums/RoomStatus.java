package Hotel.RoomService.Enums;

/**
 * Enumeration of the possible statuses for a hotel room.
 * This includes whether the room is vacant or occupied and whether it is clean or dirty.
 */
public enum RoomStatus {
    VaCl("Vacant Clean"),   // Room is vacant and clean
    VaDi("Vacant Dirty"),   // Room is vacant and dirty
    OcCl("Occupied Clean"), // Room is occupied and clean
    OcDi("Occupied Dirty"), // Room is occupied and dirty
    OOO("Out Of Order");    // Room is out of order and not available for use

    private final String description;

    // Constructor to set the human-readable description
    RoomStatus(String description) {
        this.description = description;
    }

    /**
     * Returns a description of the room status.
     * @return The descriptive text of the room status.
     */
    public String getDescription() {
        return description;
    }

    /**
     * Returns the next status in the enumeration, cycling back to the first after the last.
     * @return The next RoomStatus in the enumeration.
     */
    public RoomStatus next() {
        // Cycles through the enum values circularly using ordinal values
        RoomStatus[] types = values();
        return types[(this.ordinal() + 1) % types.length];
    }
}