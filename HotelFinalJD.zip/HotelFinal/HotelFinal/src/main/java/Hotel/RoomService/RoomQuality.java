package Hotel.RoomService;

import Hotel.RoomService.Enums.BedType;
import Hotel.RoomService.Enums.QualityLevel;
import Hotel.RoomService.Enums.RoomStatus;
import Hotel.RoomService.Enums.RoomType;

/**
 * Represents a hotel room with extended features, including room type and quality level.
 */
public class RoomQuality extends Room {
    // Additional room attributes
    private RoomType roomType;
    private QualityLevel qualityLevel;

    /**
     * Constructs a RoomQuality object with specified attributes including room type and quality level.
     *
     * @param roomStatus    The status of the room (e.g., Vacant, Occupied).
     * @param bedType       The type of bed in the room (e.g., King, Queen).
     * @param roomType      The type of the room (e.g., Suite, Deluxe).
     * @param qualityLevel  The quality level of the room (e.g., Executive, Economy).
     * @param smokingStatus Whether smoking is allowed in the room.
     * @param roomNumber    The room number identifier.
     * @throws Exception if an initialization error occurs, particularly if any value is null.
     */
    public RoomQuality(RoomStatus roomStatus, BedType bedType, RoomType roomType,
                       QualityLevel qualityLevel, Boolean smokingStatus, Integer roomNumber) throws Exception {
        super(roomStatus, bedType, smokingStatus, roomNumber);
        this.setRoomType(roomType);
        this.setQualityLevel(qualityLevel);
        System.out.println("Successfully initialized RoomQuality");
    }

    /**
     * Sets the room type of this room.
     *
     * @param roomType The type of the room.
     * @throws Exception if roomType is null or setting fails.
     */
    public void setRoomType(RoomType roomType) throws Exception {
        if (roomType == null) {
            throw new Exception("Fatal error thrown in setRoomType, value is NULL");
        }
        this.roomType = roomType;
    }

    /**
     * Sets the quality level of this room.
     *
     * @param qualityLevel The quality level of the room.
     * @throws Exception if qualityLevel is null or setting fails.
     */
    public void setQualityLevel(QualityLevel qualityLevel) throws Exception {
        if (qualityLevel == null) {
            throw new Exception("Fatal error thrown in setQualityLevel, value is NULL");
        }
        this.qualityLevel = qualityLevel;
    }

    /**
     * Returns the room type of this room.
     *
     * @return The type of the room.
     */
    public RoomType getRoomType() {
        return this.roomType;
    }

    /**
     * Returns the quality level of this room.
     *
     * @return The quality level of the room.
     */
    public QualityLevel getQualityLevel() {
        return this.qualityLevel;
    }

    /**
     * Compares this room with another RoomQuality object to determine if they match in terms of bed type, room type,
     * quality level, and smoking status.
     *
     * @param rm The RoomQuality object to compare against.
     * @return true if all properties match, false otherwise.
     */
    public boolean match(RoomQuality rm) {
        return bedType.equals(rm.bedType) && roomType.equals(rm.roomType) &&
                qualityLevel.equals(rm.qualityLevel) && smokingStatus.equals(rm.smokingStatus);
    }

    /**
     * Provides a string representation of the room quality details.
     *
     * @return A string describing the detailed attributes of the room.
     */
    @Override
    public String toString() {
        return super.toString() + ", " + this.roomType + ", " + this.qualityLevel;
    }
}