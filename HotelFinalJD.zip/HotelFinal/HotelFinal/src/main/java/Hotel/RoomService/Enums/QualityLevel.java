package Hotel.RoomService.Enums;

/**
 * Enum representing the quality level of a hotel room.
 */
public enum QualityLevel {
    // Executive Level, Business Level, Comfort Level, Economy Level
    ExL, BuL, CoL, EcL;
    private static final QualityLevel[] types = values();

    /**
     * Cycles to the next quality level in the enum sequence.
     * @return the next QualityLevel in the sequence.
     */
    public QualityLevel next() {
        return types[(this.ordinal() + 1) % types.length];
    }

    /**
     * Converts a string to its corresponding QualityLevel enum.
     * @param str the string to convert.
     * @return the corresponding QualityLevel.
     * @throws IllegalArgumentException if the string does not match any QualityLevel.
     */
    public static QualityLevel getEnum(String str) {
        str = str.toLowerCase();
        if (str.contains("ex")) {
            return QualityLevel.ExL;
        } else if (str.contains("bu")) {
            return QualityLevel.BuL;
        } else if (str.contains("co")) {
            return QualityLevel.CoL;
        } else if (str.contains("eco")) {
            return QualityLevel.EcL;
        } else {
            throw new IllegalArgumentException("Invalid QualityLevel");
        }
    }
}
