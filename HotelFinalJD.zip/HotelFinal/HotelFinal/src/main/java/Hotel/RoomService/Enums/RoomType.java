package Hotel.RoomService.Enums;

/**
 * Enum representing the type of a hotel room.
 */
public enum RoomType {
    FM, // Family
    DB, // Double
    SN, // Single
    DL, // Deluxe
    SU, // Suite
    ST; // Standard

    private static final RoomType[] types = values();

    /**
     * Cycles to the next room type in the enum sequence.
     * @return the next RoomType in the sequence.
     */
    public RoomType next() {
        return types[(this.ordinal() + 1) % types.length];
    }

    /**
     * Converts a string to its corresponding RoomType enum.
     * @param str the string to convert.
     * @return the corresponding RoomType.
     * @throws IllegalArgumentException if the string does not match any RoomType.
     */
    public static RoomType getEnum(String str) {
        str = str.toLowerCase();
        if (str.contains("fam")) {
            return RoomType.FM;
        } else if (str.contains("dou")) {
            return RoomType.DB;
        } else if (str.contains("sin")) {
            return RoomType.SN;
        } else if (str.contains("del")) {
            return RoomType.DL;
        } else if (str.contains("su")) {
            return RoomType.SU;
        } else if (str.contains("st")) {
            return RoomType.ST;
        } else {
            throw new IllegalArgumentException("Invalid RoomType");
        }
    }
}
