
import Hotel.Central.CentralDatabase;
import Hotel.LoggerPackage.MyLogger;
import Hotel.UI.LoginFrame;

import java.util.logging.Level;

/**
 * Main class that serves as the entry point for the hotel management application.
 */
public class Main {
    /**
     * The main method to start the application.
     * Initializes necessary services and loads the login interface.
     *
     * @param args Command line arguments passed to the application (not used).
     */
    public static void main(String[] args) {
        if(!CentralDatabase.init()) {
            MyLogger.logger.log(Level.SEVERE, "Cannot initialize Central Database. Exiting program...");
            System.exit(1);
        }
        
        LoginFrame login = new LoginFrame();
        login.setVisible(true);
    }
}
