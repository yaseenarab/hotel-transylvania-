package exampls;



import exampls.UI.LoginFrame;

import javax.swing.*;


public class main {
    public static void main(String[] args) throws Exception {
        Person.Arlow.init();
        Reservations.Marsha.init();

        JFrame login = new LoginFrame();

        login.setVisible(true);

    }
    public static JTextField addJTextFeild(int x, int y, int width, int height){
        JTextField textFeild = new JTextField();
        textFeild.setBounds(x,y, width ,height);


        return textFeild;

    }

    public static JLabel addLabel(String label, int x, int y, int width, int height){
        JLabel jLabel = new JLabel(label);
        jLabel.setBounds(x,y,width,height);


        return jLabel;
    }

    public static JButton login(){
        JButton login = new JButton("login");
        login.setBounds(142,250, 100 ,30);


        return login;
    }
}